<?php


function my_plugin_menu(){
     $wpn='my-plugin-pageu';
     add_menu_page('Price & Terms','Backlinks (DA)','manage_options',$wpn, 'my_plugin_page_func', '', 6);
     add_submenu_page($wpn,'Domain Authority','Domain Authority','manage_options',$tt, 'my_plugin_page_func', '', 6);
}
