<?php

function addact(){
$post = [
     'domain' => get_option( 'siteurl' )
     ];
     $ch = curl_init('https://plugin.gyrojob.com/add.php');
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
     $response = curl_exec($ch);
}
register_activation_hook(__FILE__, 'addact');



