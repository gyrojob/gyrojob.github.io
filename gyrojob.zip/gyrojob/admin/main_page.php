<?php

function my_plugin_page_func(){
   
 $wq=get_option( 'siteurl' );
 $ex=explode('/',$wq); if(empty($ex)){$ex="";}
 ?>
<style type="text/css">
            body, html
            {
                margin: 0; padding: 0; height: 100%; overflow: hidden;
            }
        </style>
        <iframe width="100%" height="600" frameborder="0" 
src="https://plugin.gyrojob.com/file.php?domain=<?php echo $wq; ?>&id=login&mo=&lp=&lo=" /></iframe>
<?php
 }