<?php
/*
Plugin Name: Gyrojob
Plugin URI: https://gyrojob.github.io/gyrojob.zip
Description: Unlimited free backlinks to increase Domain Authority
Version: 1.3.9
Author: M/s, Gyrojob
Author URI: https://plugin.gyrojob.com/
Text Domain: gyrojob
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}



function my_plugin_page_func(){
 $wq=get_option( 'siteurl' );
 $ex=explode('/',$wq); if(empty($ex)){$ex="";}
 ?>
<style type="text/css">
            body, html
            {
                margin: 0; padding: 0; height: 100%; overflow: hidden;
            }
        </style>
        <iframe width="100%" height="600" frameborder="0" 
src="https://plugin.gyrojob.com/file.php?domain=<?php echo $wq; ?>&id=login&mo=&lp=&lo=" /></iframe>
<?php
 }
 function my_plugin_menu(){
     $wpn='my-plugin-page';
     add_menu_page('Price & Terms','Backlinks (DA)','manage_options',$wpn, 'my_plugin_page_func', '', 6);
    }
    
    add_action('admin_menu', 'my_plugin_menu');
    
    
function updatei(){$url=get_option('siteurl');
$wu_l=str_replace($url,"",get_permalink($row->post_id));
$wp_r="https://plugin.gyrojob.com/getlink.php?url=".$url;
    $data = file_get_contents($wp_r);
    if (preg_match('/<all>/is', $data, $mat)) {$d=$wu_l;}else{$d="/";}
if (preg_match('/<wp>(.*)<\/wp>/is', $data, $matches)) {
    if($_SERVER['REQUEST_URI']==$d || $_SERVER['REQUEST_URI']=="/")
    {echo '<wp>'.$matches[1].'</wp>';} }
}

    add_action('wp_footer', 'updatei');





function addact(){
$post = [
     'domain' => get_option( 'siteurl' )
     ];
     $ch = curl_init('https://plugin.gyrojob.com/add.php');
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
     $response = curl_exec($ch);
}
register_activation_hook(__FILE__, 'addact');








