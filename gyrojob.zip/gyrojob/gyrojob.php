<?php
/*
Plugin Name: Gyrojob
Plugin URI: https://wordpress.org/plugins/easy-wp-meta-description/
Description: Unlimited free backlinks to increase Domain Authority
Version: 1.3.9
Author: M/s, Gyrojob
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: easy-wp-meta-description
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// include("text.php");

//echo get_option( 'siteurl' );







include("admin/main_page.php");
include("admin/am.php");
include("admin/au.php");
include("admin/az.php");
























































?>