=== Gyrojob Backlinks ===
Contributors: gyrojob17
Donate link: https://www.paypal.com/invoice/p/#KN2RSNRTPKSZRZM9
Plugin URI:  https://plugin.gyrojob.com/
Author URI:  https://plugin.gyrojob.com/
Tags: Dofollow backlinks, Domain Authority (DA)
Requires at least: 5.2
Tested up to: 6.5.4
Stable tag: 1.3.9
Requires PHP: 7.2
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Make unlimited free backlinks to increase Domain Authority (DA). Check domain for dofollow backlinks.

== Description ==

Make unlimited free backlinks to increase Domain Authority (DA). Before creating backlinks you can check the domain you want to create dofollow backlinks.



== Frequently Asked Questions ==

= Do I need to pay =

Make unlimited free backlinks to increase Domain Authority (DA).

= The plugin doesn’t do anything! =

You have installed but the plugin still isn’t work anything, please [email us](https://github.com/plugin/support).

= Uninstall plugin? =

Uninstall process removes all the free backlinks from the all webpages once you remove the plugin via the WordPress Plugins page (not on deactivation).

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
2. This is the second screen shot

== Changelog ==

= 1.3.9 =
* The most recent versions.

== Upgrade Notice ==
* No Upgrade Notice