<?php
/**
 * Plugin Name: Basicweb SEO
 * Plugin URI:        https://plugin.gyrojob.com/basicweb-seo.php
 * Description:       SEO, Organic seo, Image seo, Video seo, web promotion, Google seo with META titles, descriptions tag. optimizes your Wordpress blog for Search Engines (Search Engine Optimization).
 * Version:           1.3.24
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: basicweb-seo
 */

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}









require_once plugin_dir_path(__FILE__) . 'inc/basicweb-home.php';
if ( ! function_exists( 'Basicweb_SEO_Meta_Home_Description' ) ) {
new Basicweb_SEO_Meta_Home_Description();
}


require_once plugin_dir_path(__FILE__) . 'inc/basicweb-postpagesshop.php';
if ( ! function_exists( 'Basicweb_SEO_Page_Shop_Description' ) ) {
new Basicweb_SEO_Page_Shop_Description();
}


require_once plugin_dir_path(__FILE__) . 'inc/basicweb-texonomi.php';
if ( ! function_exists( 'Basicweb_SEO_Texo_Nomy' ) ) {
new Basicweb_SEO_Texo_Nomy();
}


require_once plugin_dir_path(__FILE__) . 'inc/basicweb-media.php';
if ( ! function_exists( 'Basicweb_SEO_Media_Tags' ) ) {
new Basicweb_SEO_Media_Tags();
}














