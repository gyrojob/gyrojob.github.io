<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Basicweb_SEO_Texo_Nomy {

    public function __construct() {
        // Add meta fields to the term editing pages



add_action( 'category_add_form_fields', [$this, 'basicweb_seo_add_taxonomy_meta_fields'] );
add_action( 'post_tag_add_form_fields', [$this, 'basicweb_seo_add_taxonomy_meta_fields'] );


add_action( 'category_edit_form_fields', [$this, 'basicweb_seo_edit_taxonomy_meta_fields'], 10, 2 );
add_action( 'post_tag_edit_form_fields', [$this, 'basicweb_seo_edit_taxonomy_meta_fields'], 10, 2 );



add_action( 'edited_category', [$this, 'basicweb_seo_save_taxonomy_meta'], 10, 2 );
add_action( 'edited_post_tag', [$this, 'basicweb_seo_save_taxonomy_meta'], 10, 2 );



add_action( 'edited_category', [$this, 'basicweb_seo_save_taxonomy_meta'] );
add_action( 'create_category', [$this, 'basicweb_seo_save_taxonomy_meta'] );
add_action( 'edited_post_tag', [$this, 'basicweb_seo_save_taxonomy_meta'] );
add_action( 'create_post_tag', [$this, 'basicweb_seo_save_taxonomy_meta'] );






        // Display custom meta tags in the head of category/tag pages
        add_action( 'wp_head', [$this, 'basicweb_seo_output_taxonomy_meta_tags'] );
    }





// Add meta boxes to taxonomy edit screens.

    public function basicweb_seo_add_taxonomy_meta_fields( $taxonomy ) {
                // Add a nonce field.
    wp_nonce_field( 'basicweb_seo_save_taxonomy_meta', 'basicweb_seo_meta_tagss_nonce' );
    ?>
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_title"><h1>Basicweb SEO</h1></label></th>
    </tr> 
    <div class="form-field">
        <label for="basicweb_seo_meta_title"><?php esc_html_e( 'Meta Title', 'basicweb-seo' ); ?></label>
        <input type="text" id="basicweb_seo_meta_title" name="basicweb_seo_meta_title" value="" class="regular-text">
    </div>
    <div class="form-field">
        <label for="basicweb_seo_meta_description"><?php esc_html_e( 'Meta Description', 'basicweb-seo' ); ?></label>
        <textarea id="basicweb_seo_meta_description" name="basicweb_seo_meta_description" class="large-text" rows="3"></textarea>
    </div>
    <div class="form-field">
        <label for=basicweb_seo_meta_keywords"><?php esc_html_e( 'Meta Keywords', 'basicweb-seo' ); ?></label>
        <input type="text" id="basicweb_seo_meta_keywords" name="basicweb_seo_meta_keywords" value="" class="regular-text">
    </div>
    <div class="form-field">
        <label><?php esc_html_e( 'Noindex', 'basicweb-seo' ); ?></label>
        <label><input type="radio" name="basicweb_seo_meta_noindex" value="1"> <?php esc_html_e( 'Yes', 'basicweb-seo' ); ?></label>
        <label><input type="radio" name="basicweb_seo_meta_noindex" value="0" checked> <?php esc_html_e( 'No', 'basicweb-seo' ); ?></label>
    </div>
    <div class="form-field">
        <label><?php esc_html_e( 'Nofollow', 'basicweb-seo' ); ?></label>
        <label><input type="radio" name="basicweb_seo_meta_nofollow" value="1"> <?php esc_html_e( 'Yes', 'basicweb-seo' ); ?></label>
        <label><input type="radio" name="basicweb_seo_meta_nofollow" value="0" checked> <?php esc_html_e( 'No', 'basicweb-seo' ); ?></label>
    </div>
    <div class="form-field">
        <label for="basicweb_seo_meta_canonical"><?php esc_html_e( 'Canonical URL', 'basicweb-seo' ); ?></label>
        <input type="url" id="basicweb_seo_meta_canonical" name="basicweb_seo_meta_canonical" value="" class="regular-text">
    </div>
    <?php
}












public function basicweb_seo_edit_taxonomy_meta_fields( $term, $taxonomy ) {
        // Add a nonce field.
    wp_nonce_field( 'basicweb_seo_save_taxonomy_meta', 'basicweb_seo_meta_tagss_nonce' );
    
    $meta_title = get_term_meta( $term->term_id, '_basicweb_seo_meta_title', true );
    $meta_description = get_term_meta( $term->term_id, '_basicweb_seo_meta_description', true );
    $meta_keywords = get_term_meta( $term->term_id, '_basicweb_seo_meta_keywords', true );
    $meta_noindex = get_term_meta( $term->term_id, '_basicweb_seo_meta_noindex', true );
    $meta_nofollow = get_term_meta( $term->term_id, '_basicweb_seo_meta_nofollow', true );
    $meta_canonical = get_term_meta( $term->term_id, '_basicweb_seo_meta_canonical', true );

    ?>
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_title"><h1>Basicweb SEO</h1></label></th>
    </tr>    
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_title"><?php esc_html_e( 'Meta Title', 'basicweb-seo' ); ?></label></th>
        <td><input type="text" id="basicweb_seo_meta_title" name="basicweb_seo_meta_title" value="<?php echo esc_attr( $meta_title ); ?>" class="regular-text"></td>
    </tr>
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_description"><?php esc_html_e( 'Meta Description', 'basicweb-seo' ); ?></label></th>
        <td><textarea id="basicweb_seo_meta_description" name="basicweb_seo_meta_description" class="large-text" rows="3"><?php echo esc_textarea( $meta_description ); ?></textarea></td>
    </tr>
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_keywords"><?php esc_html_e( 'Meta Keywords', 'basicweb-seo' ); ?></label></th>
        <td><input type="text" id="basicweb_seo_meta_keywords" name="basicweb_seo_meta_keywords" value="<?php echo esc_attr( $meta_keywords ); ?>" class="regular-text"></td>
    </tr>
    <tr class="form-field">
        <th><?php esc_html_e( 'Noindex', 'basicweb-seo' ); ?></th>
        <td>
            <label><input type="radio" name="basicweb_seo_meta_noindex" value="1" <?php checked( $meta_noindex, '1' ); ?>> <?php esc_html_e( 'Yes', 'basicweb-seo' ); ?></label>
            <label><input type="radio" name="basicweb_seo_meta_noindex" value="0" <?php checked( $meta_noindex, '0' ); ?> checked> <?php esc_html_e( 'No', 'basicweb-seo' ); ?></label>
        </td>
    </tr>
    <tr class="form-field">
        <th><?php esc_html_e( 'Nofollow', 'basicweb-seo' ); ?></th>
        <td>
            <label><input type="radio" name="basicweb_seo_meta_nofollow" value="1" <?php checked( $meta_nofollow, '1' ); ?>> <?php esc_html_e( 'Yes', 'basicweb-seo' ); ?></label>
            <label><input type="radio" name="basicweb_seo_meta_nofollow" value="0" <?php checked( $meta_nofollow, '0' ); ?> checked> <?php esc_html_e( 'No', 'basicweb-seo' ); ?></label>
        </td>
    </tr>
    <tr class="form-field">
        <th><label for="basicweb_seo_meta_canonical"><?php esc_html_e( 'Canonical URL', 'basicweb-seo' ); ?></label></th>
        <td><input type="url" id="basicweb_seo_meta_canonical" name="basicweb_seo_meta_canonical" value="<?php echo esc_attr( $meta_canonical ); ?>" class="regular-text"></td>
    </tr>
    <?php
}





















// Save taxonomy meta fields.
public function basicweb_seo_save_taxonomy_meta( $term_id ) {
        // Verify nonce.
    if ( ! isset( $_POST['basicweb_seo_meta_tagss_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['basicweb_seo_meta_tagss_nonce'])), 'basicweb_seo_save_taxonomy_meta' ) ) {
        return;
    }
    if ( isset( $_POST['basicweb_seo_meta_title'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_title', sanitize_text_field( wp_unslash($_POST['basicweb_seo_meta_title']) ) );
    }
    if ( isset( $_POST['basicweb_seo_meta_description'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_description', sanitize_textarea_field(wp_unslash( $_POST['basicweb_seo_meta_description']) ) );
    }
    if ( isset( $_POST['basicweb_seo_meta_keywords'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_keywords', sanitize_text_field(wp_unslash( $_POST['basicweb_seo_meta_keywords']) ) );
    }
    if ( isset( $_POST['basicweb_seo_meta_noindex'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_noindex', sanitize_text_field(wp_unslash( $_POST['basicweb_seo_meta_noindex']) ) );
    }
    if ( isset( $_POST['basicweb_seo_meta_nofollow'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_nofollow', sanitize_text_field(wp_unslash( $_POST['basicweb_seo_meta_nofollow']) ) );
    }
    if ( isset( $_POST['basicweb_seo_meta_canonical'] ) ) {
        update_term_meta( $term_id, '_basicweb_seo_meta_canonical', esc_url_raw(wp_unslash( $_POST['basicweb_seo_meta_canonical']) ) );
    }
}




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

   
   


// Output custom meta tags for taxonomy archive pages.
public function basicweb_seo_output_taxonomy_meta_tags() {
    if ( is_category() || is_tag() ) {
        $term_id = get_queried_object_id();

        $meta_title = get_term_meta( $term_id, '_basicweb_seo_meta_title', true );
        $meta_description = get_term_meta( $term_id, '_basicweb_seo_meta_description', true );
        $meta_keywords = get_term_meta( $term_id, '_basicweb_seo_meta_keywords', true );
        $meta_noindex = get_term_meta( $term_id, '_basicweb_seo_meta_noindex', true );
        $meta_nofollow = get_term_meta( $term_id, '_basicweb_seo_meta_nofollow', true );
        $meta_canonical = get_term_meta( $term_id, '_basicweb_seo_meta_canonical', true );
        ?>
        
        <!-- Basicweb seo Meta Description -  -->
        
        <?php
        if ( $meta_title ) {
            echo '<title>' . esc_html( $meta_title ) . '</title>' . "\n";
        }
        if ( $meta_description ) {
            echo '<meta name="description" content="' . esc_attr( $meta_description ) . '">' . "\n";
        }
        if ( $meta_keywords ) {
            echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '">' . "\n";
        }
        if ( $meta_noindex === '1' ) {
            echo '<meta name="robots" content="noindex">' . "\n";
        }
        if ( $meta_nofollow === '1' ) {
            echo '<meta name="robots" content="nofollow">' . "\n";
        }
        if ( $meta_canonical ) {
            echo '<link rel="canonical" href="' . esc_url( $meta_canonical ) . '">' . "\n";
        } ?>
        
        <!-- END basicweb seo Meta Description - -->
        
        <?php    
    }
}




}







