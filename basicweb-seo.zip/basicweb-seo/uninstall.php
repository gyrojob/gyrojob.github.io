<?php

// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
 
basicweb_seo_meta_tags_handle_site();

if( is_multisite() ){
	
	// wordpress 4.6
	if( function_exists( 'get_sites' ) && class_exists( 'WP_Site_Query' ) ) {
		$sites = get_sites();
		foreach( $sites as $site ){
			switch_to_blog( $site->blog_id );
			basicweb_seo_meta_tags_handle_site();
		}
	}
	else{
		
		// wordpress < 4.6
		if( function_exists( 'get_sites' ) ) {
			$sites = get_sites();
			foreach ( $sites as $site ) {
				switch_to_blog( $site['blog_id'] );
				basicweb_seo_meta_tags_handle_site();
			}
		}
	}
}















function basicweb_seo_meta_tags_handle_site(){
    
    
    
    
    
	// drop option
	delete_option( 'basicweb_seo_meta_title' );
	delete_option( 'basicweb_seo_meta_description' );
	delete_option( 'basicweb_seo_meta_keywords' );
	delete_option( 'basicweb_seo_noindex' );
	delete_option( 'basicweb_seo_nofollow' );
	delete_option( 'basicweb_seo_canonical' );
	
	
	
	// drop post meta
	delete_post_meta_by_key( '_basicweb_seo_post_meta_title' );	
	delete_post_meta_by_key( '_basicweb_seo_post_meta_description' );
	delete_post_meta_by_key( '_basicweb_seo_post_meta_keywords' );
	delete_post_meta_by_key( '_basicweb_seo_post_meta_noindex' );
	delete_post_meta_by_key( '_basicweb_seo_post_meta_nofollow' );
	delete_post_meta_by_key( '_basicweb_seo_post_meta_canonical' );
	
	
		// drop taxonomy meta
	delete_post_meta_by_key( '_basicweb_seo_meta_title' );	
	delete_post_meta_by_key( '_basicweb_seo_meta_description' );
	delete_post_meta_by_key( '_basicweb_seo_meta_keywords' );
	delete_post_meta_by_key( '_basicweb_seo_meta_noindex' );
	delete_post_meta_by_key( '_basicweb_seo_meta_nofollow' );
	delete_post_meta_by_key( '_basicweb_seo_meta_canonical' );
	
	
	
	
	
	                          
	
	
	
}
 
 

?>