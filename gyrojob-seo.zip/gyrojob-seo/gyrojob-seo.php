<?php
/*
 * Plugin Name:       Gyrojob SEO
 * Plugin URI:        https://plugin.gyrojob.com/gyrojob-seo.php
 * Description:       SEO, Organic seo, Image seo, Video seo, web promotion, Google seo with META titles, descriptions tag. optimizes your Wordpress blog for Search Engines (Search Engine Optimization).
 * Version:           1.3.23
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gyrojob-seo
 */


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}






require_once(ABSPATH . "/wp-admin/includes/plugin.php");
require_once(ABSPATH . "/wp-admin/includes/file.php");
require_once(ABSPATH . "/wp-admin/includes/class-wp-upgrader.php");





$Gyrojob_SEO_Meta_Description = new Gyrojob_SEO_Meta_Description();
$Gyrojob_SEO_Meta_Description->run();

class Gyrojob_SEO_Meta_Description{

	private $plugin_name;
	private $meta_title;
	private $meta_description;
	private $meta_desc;
	private $meta_advance;
	private $meta_noindex;
	private $meta_nofollow;
	private $show_on_front;

	function __construct(){
	    $this->plugin_name = 'gyrojob-seo';
		$this->meta_title = '_gyrojob_seo_meta_title';
		$this->meta_description = '_gyrojob_seo_meta_description';
        $this->meta_desc = '_gyrojob_seo_meta_desc';
        $this->meta_advance = '_gyrojob_seo_meta_advance';
        $this->meta_noindex = '_gyrojob_seo_meta_noindex';
        $this->meta_nofollow = '_gyrojob_seo_meta_nofollow';
		// tells if a page has been selected as front page
		// possible values 'posts' and 'page'
		$this->show_on_front = get_option( 'show_on_front' );
	}

	function run(){
		if( is_admin() ){
		    
		    add_action( 'admin_menu', array( $this, 'gyrojob_seo_hook_admin_head') );
		    add_action( 'init', array( $this, 'load_plugin_gyrojob_lan' ) );
			add_action( 'add_meta_boxes', array( $this, 'description_meta_box') );
			add_action( 'save_post', array( $this, 'save_description' ) );
			if( $this->show_on_front == 'posts' ){
				add_action( 'admin_init', array( $this, 'setting_page' ) );
			}
		}
		else{
		    
		    
		               
		    add_action( 'wp_head', array( $this, 'customi') );
			//remove_action( 'wp_head', 'rel_canonical' );
			add_action( 'wp_head', array( $this, 'gyrojobinsert_meta_in_head' ),  1 );
			//add_action( 'wp_head', 'rel_canonical' );
            //add_action( 'init', [$this, 'cachetext'] );
            //add_filter( 'document_title_parts', array( $this, 'gyrojob_html_title'), 1 );
            //add_filter( 'pre_get_document_title', array( $this, 'gyrojob_page_replace_title'), 1 );
            add_filter('pre_get_document_title', array( $this, 'change_my_404_title'));

        }
	}
	

	function change_my_404_title($title) {
     // checks if 404 error is being displayed
    if ( is_404() ) {
       return 'Error 404: Oh no. Page note found';
     }
     else if (is_single($title) ) {
     return ' ';
     }
          else if (is_home($title) ) {
     return ' ';
     }
               else if (is_page($title) ) {
     return ' ';
     }
     // else return default title
     return $title;
}
	
	
	
	
function gyrojob_seo_hook_admin_head(){
    wp_enqueue_style( 'gyrojob-seo', ( plugin_dir_url( __FILE__ ) . 'gyrocss.css' ), array(), filemtime( plugin_dir_path( __FILE__ ) . 'gyrocss.css' ) );
    wp_enqueue_script( 'gyrojob-seo', ( plugin_dir_url( __FILE__ ) . 'gyroscript.js' ), array( 'jquery', 'postbox' ), filemtime( plugin_dir_path( __FILE__ ) . 'gyroscript.js' ), false );
    wp_enqueue_script( 'gyrojob-seo-myscript', ( plugin_dir_url( __FILE__ ) . 'mygyroscript.js' ), array( 'jquery', 'postbox' ), filemtime( plugin_dir_path( __FILE__ ) . 'mygyroscript.js' ), true );
}
    	
 



	
	
	
	
	function setting_page(){

		$option_group = 'general';
		$option_name = 'gyrojob_seo_meta_description_front';
		$option_title = 'gyrojob_seo_meta_title_front';
		$option_key = 'gyrojob_seo_meta_key_front';
			
		register_setting( $option_group, $option_name);
		register_setting( $option_group, $option_title);
		register_setting( $option_group, $option_key);

		$id = 'gyrojob_seo_description';
		$title = __( '<h3>Gyrojob SEO<br></h3>', 'gyrojob-seo' );
		$callback = array( $this, 'front_descr_input' );
		$page = 'general';
		$section = 'default';
		$args = array( 'label_for' => 'gyrojob_seo_meta_description_front' );
		$argstit = array( 'label_for' => 'gyrojob_seo_meta_title_front' );
		$argskey = array( 'label_for' => 'gyrojob_seo_meta_key_front' );
	
		add_settings_field( $id, $title, $callback, $page, $section, $args );
		add_settings_field( $id, $title, $callback, $page, $section, $argstit );
		add_settings_field( $id, $title, $callback, $page, $section, $argskey );

	}



 



	function front_descr_input(){
		$setting = get_option( 'gyrojob_seo_meta_description_front' );
			$settingdesc = get_option( 'gyrojob_seo_meta_title_front' );
				$settingkey = get_option( 'gyrojob_seo_meta_key_front' );
		?><h3>Type home page title</h3>
<input type="text" size="120" name="gyrojob_seo_meta_title_front" id="gyrojob_seo_description"  
	class="regular-text1" value="<?php print esc_attr($settingdesc); ?>">
	
	
<br><br><h3>Type home page description</h3>
	<textarea class="wp-editor-area" id="gyrojob_seo_description" name="gyrojob_seo_meta_description_front" cols="80" rows="5">
<?php print esc_attr($setting); ?></textarea>
	
	<br><br>
	

	<h3>Facebook description</h3>
	<textarea class="wp-editor-area" id="gyrojob_seo_description" name="gyrojob_seo_meta_key_front" cols="80" rows="5">
<?php print esc_attr($settingkey); ?></textarea>
	
	
	
	<?php /* ?>
<p class="description" id="meta-description"><?php
	_e( 'Added by', 'gyrojob-seo-meta-description' ); ?>  Gyrojob SEO Meta Description. <?php
	_e( 'Character count', 'gyrojob-seo-meta-description' ); ?>: <span id="gyrojob_seo_output"></span></p>
		<?php
*/	
	    
	}








	function load_plugin_gyrojob_lan(){
		load_plugin_textdomain( 'gyrojob-seo', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}
    function customi(){ ?>
       <META NAME='ROBOTS' CONTENT='NOARCHIVE' />
    <?php }


	function gyrojobinsert_meta_in_head(){
	   
		$description = '';
		$title = '';
		$dioi = '';
		$advance= '';
	    $noindex='';
	    $nofollow='';

		if( ! is_paged() ){
			if( is_single() or is_page()){
				global $post;
				$title = get_post_meta( $post->ID, $this->meta_title, true );
				$description = get_post_meta( $post->ID, $this->meta_description, true );
				$advance = get_post_meta( $post->ID, $this->meta_advance, true);
				$dioi = get_post_meta( $post->ID, $this->meta_desc, true);
				$noindex = get_post_meta( $post->ID, $this->meta_noindex, true);
				$nofollow = get_post_meta( $post->ID, $this->meta_nofollow, true);
			}
			elseif( is_tag() or is_category() or is_tax()){
				$remove = array( '<p>', '</p>' );
				$description = trim( str_replace( $remove, '', term_description() ) );
			}
		elseif( is_front_page() ){
				if( $this->show_on_front == 'posts' ){
					if( ! $description = get_option( 'gyrojob_seo_meta_description_front' ) ){
						$description = get_bloginfo( 'description', 'display' );
					}
					if( ! $descriptiontitl = get_option( 'gyrojob_seo_meta_title_front') ){
						$descriptiontitl = get_bloginfo( 'descriptiontitl', 'display' );
					}				
					if(!$descriptionog = get_option( 'gyrojob_seo_meta_key_front')){
	            	    $descriptionog = get_bloginfo( 'descriptionkey', 'display' );
	            	}
	            }
				else{
					$post_id = get_option( 'page_on_front' );
					$description = get_post_meta( $post_id, $this->meta_desc, true );
				}
			}
			elseif( is_home() ){
				$home_id = get_option( 'page_for_posts' );
				$description = get_post_meta( $home_id, $this->meta_desc, true );
			}
			
		}
		?>
		
		
    <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
        <?php
//	if($description && !is_page() && is_home()){


if($description  && is_home() ){
				?>
				

    <title><?php print esc_attr($descriptiontitl); ?></title>
    <meta name="description" content="<?php echo esc_attr($description); ?>" />
	<meta property="og:locale" content="" class="Gyrojob-seo-meta-tag" />
	<meta property="og:type" content="article" class="Gyrojob-seo-meta-tag" />
	<meta property="og:title" content="<?php print esc_attr($descriptiontitl); ?>" class="Gyrojob-seo-meta-tag" />
	<meta property="og:description" content="<?php print esc_attr($descriptionog); ?>" class="Gyrojob-seo-meta-tag" />
	<meta property="og:url" content="" class="Gyrojob-seo-meta-tag" />
	<meta property="og:site_name" content="gyrogap" class="Gyrojob-seo-meta-tag" />
	<meta property="article:modified_time" content="" class="Gyrojob-seo-meta-tag" />
	<meta name="twitter:card" content="summary_large_image" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:title" content="<?php print esc_attr($descriptiontitl); ?>" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:description" content="<?php print esc_attr($description); ?>" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:image" content="" class="Gyrojob-seo-meta-tag" />

<?php		}else if( $description ){       ?>


    <title><?php print esc_attr($title); ?></title>
    <meta name="description" content="<?php echo esc_attr($description); ?>" />
    <meta name="robots" content="<?php if($noindex==''){echo 'index';}else{echo esc_attr($noindex);} ?>, <?php if($nofollow==''){echo 'follow';}else{echo esc_attr($nofollow);} ?>" />
<?php if($advance==''){}else{ ?>
    <link rel="canonical" href="<?php echo esc_url($advance); ?>" />
    <?php } ?>
	<meta property="og:locale" content="" class="Gyrojob-seo-meta-tag" />
	<meta property="og:type" content="article" class="Gyrojob-seo-meta-tag" />
	<meta property="og:title" content="<?php print esc_attr($title); ?>" class="Gyrojob-seo-meta-tag" />
	<meta property="og:description" content="<?php print esc_attr($dioi); ?>" class="Gyrojob-seo-meta-tag" />
	<meta property="og:url" content="<?php if($advance!=''){echo esc_url($advance);}else{echo esc_url(get_permalink());} ?>" class="Gyrojob-seo-meta-tag" />
	<meta property="og:site_name" content="gyrogap" class="Gyrojob-seo-meta-tag" />
	<meta property="article:modified_time" content="" class="Gyrojob-seo-meta-tag" />
	<meta name="twitter:card" content="summary_large_image" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:title" content="<?php print esc_attr($title); ?>" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:description" content="<?php print esc_attr($description); ?>" class="Gyrojob-seo-meta-tag" />
    <meta name="twitter:image" content="" class="Gyrojob-seo-meta-tag" />

		<?php
		}
		
		?>

	<!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
	
		
	<?php	
		
	}

/*
    function gyrojob_page_replace_title(){
				if( ! is_paged() ){
			if( is_single() or is_page()){
				global $post;
				$title = get_post_meta( $post->ID, $this->meta_title, true );
			//	$description = get_post_meta( $post->ID, $this->meta_description, true );
			//	$advance = get_post_meta( $post->ID, $this->meta_advance, true);
			//	$noindex = get_post_meta( $post->ID, $this->meta_noindex, true);
			//	$nofollow = get_post_meta( $post->ID, $this->meta_nofollow, true);
			}
			elseif( is_tag() or is_category() or is_tax()){
				$remove = array( '<p>', '</p>' );
				$description = trim( str_replace( $remove, '', term_description() ) );
			}
		elseif( is_front_page() ){
				if( $this->show_on_front == 'posts' ){
					if( ! $description = get_option( 'gyrojob_seo_meta_description_front' ) ){
						$description = get_bloginfo( 'description', 'display' );
					}
					if( ! $descriptiontitl = get_option( 'gyrojob_seo_meta_title_front') ){
						$descriptiontitl = get_bloginfo( 'descriptiontitl', 'display' );
					}
	            }
				else{
					$post_id = get_option( 'page_on_front' );
					$description = get_post_meta( $post_id, $this->meta_desc, true );
				}
			}
			elseif( is_home() ){
				$home_id = get_option( 'page_for_posts' );
				$description = get_post_meta( $home_id, $this->meta_desc, true );
			}
			
		}

		if(is_page() ){
                  return $title;
                      }else if(is_home() ){
                    return $descriptiontitl;
                      }else if(is_single() ){
                    return $title;
        }
    }
*/
/*

  function gyrojob_html_title( $title ) {

         if(!is_home() or is_page()){
          return array(
                       'title' => '1111111',
                       'site'  => ''
                                   );
        }else{
            return array(
                       'title' => '2222222222',
                       'site'  => ''
                                   );
            }
        }
*/

	function description_meta_box(){
		$id = 'add_gyro_description';
		$title =  '<br>M/s, Gyrojob';
		$callback = array( $this, 'gyrojob_description_meta_box' );
		$context = 'normal';
		$priority = 'high';
		$callback_args = '';

		// get custom posttypes
		$args = array( 'public'   => true, '_builtin' => false );
		$output = 'names';
		$operator = 'and';
		$custom_posttypes = get_post_types( $args, $output, $operator );
		$builtin_posttypes = array( 'post', 'page' );
		$screens = array_merge( $builtin_posttypes, $custom_posttypes );
		foreach ( $screens as $screen ) {
			add_meta_box( $id, $title, $callback, $screen, $context,
				 $priority, $callback_args,
				 array( '__block_editor_compatible_meta_box' => false, ) );
		}
	}

	function gyrojob_description_meta_box(){
		wp_nonce_field( 'gyrojob_description_meta_box', 'gyrojob_description_meta_box_nonce' );
		$post_id = get_the_ID();
		$title = get_post_meta( $post_id, $this->meta_title, true );
		$description = get_post_meta( $post_id, $this->meta_description, true );
		$dioi = get_post_meta( $post_id, $this->meta_desc, true );
		$advance = get_post_meta( $post_id, $this->meta_advance, true );
		$noindex = get_post_meta( $post_id, $this->meta_noindex, true );
		$nofollow = get_post_meta( $post_id, $this->meta_nofollow, true );
		?>







<div  class='backbox'>
    
   <p  class='lastcol'>&nbsp;</p>
   
    
    
<div  class='secback'>

<div class="tabe"><br/>
    <h1>Gyrojob SEO Meta Description</h1>

  <br>
  <p style=''><b>Execute seo on your website for top search engine rankings - </b></p>
    
    <br>
    
    <?php if($title==''){ ?>
  <button id="titcol" class="tablinks chcola" onclick="openCity(event, 'SEO')">SEO</button>
<?php }else{ ?>  
  <button id="titcol" class="tablinks chcolb" onclick="openCity(event, 'SEO')">SEO</button>
<?php } ?>
    
    
<?php if($dioi==''){ ?>  
  <button id="keycol" class="tablinks chcola" onclick="openCity(event, 'Facebook')">Facebook</button>
  <?php }else{ ?>  
  <button id="keycol" class="tablinks chcolb" onclick="openCity(event, 'Facebook')">Facebook</button>
<?php } ?>
  
  
  
<?php if($noindex!=''){ ?>  
  <button id="nnoine" class="tablinks chcola" onclick="openCity(event, 'Robots')">Robots</button>
    <?php }else{ ?>  
  <button id="nnoine" class="tablinks chcolb" onclick="openCity(event, 'Robots')">Robots</button>
<?php } ?>
  
  
  
  <?php if($advance!=''){ ?>
  <button id="canonicals" class="tablinks chcolb" onclick="openCity(event, 'Advanced')">Advanced</button>
  <?php }else{ ?> 
  <button id="canonicals" class="tablinks chcolb" onclick="openCity(event, 'Advanced')">Advanced</button>
  <?php } ?>
  
  
  <button class="tablinks botfix" onclick="openCity(event, 'Backlinks')">Backlinks</button>


<button class="tablinks botfix" onclick="openCity(event, 'analysis')">SEO analysis</button>


</div>

<div id="SEO" class="tabcontente boxhight">
  <h3>Preview</h3>

		 <p class='pretitle' id="userMsg2"><?php if(esc_textarea($title)==''){echo '&nbsp;';}else{print esc_textarea($title);} ?></p>
		<font class='prevurl'><?php print esc_url(get_permalink()); ?></font>
		 <p class='prev' id="userMsg21"><?php if(esc_textarea($description)==''){echo '&nbsp;';}else{print esc_textarea($description);} ?></p>
		 <br/><br/><hr><br/><br/><hr>
		 
		 
	<div class="wp-editor-container">
<input class="wp-editor-area" id="userInput2" name="add_title" size=100% maxlength="72" onkeyup="showMsg2()" value="<?php
print esc_textarea($title);
?>">
</div>	
<br><br>

 <div class="wp-editor-container">
<textarea class="wp-editor-area" id="gyrojob_seo_description" name="add_gyro_description" cols="80" rows="5" onkeyup="showMsg21()"><?php
print esc_textarea($description);
?></textarea>
</div>
<h1 class="chars-counter">Character count : <span id="gyrojob_seo_output">0</span></h1>

</div>






<div id="Facebook" class="tabcontente boxhight">
  <h3>Facebook description</h3>
 
 	
		<font class='prevurl'><?php print esc_url(get_permalink()); ?></font>
		 <p class='pretitle' id="userMsg2">&nbsp;</p>
		 <p class='prev' id="userMsg21">&nbsp;</p>
		 <br/><br/><hr><br/><br/><hr>
	
	
		<div class="wp-editor-container1">
Type Facebook description
</div>	
<br><br>


 <div class="wp-editor-container">
<textarea class="wp-editor-area" id="gyrojob_seo_key" name="add_key" cols="80" rows="5" onkeyup="showkey()" ><?php
print esc_textarea($dioi);
?></textarea>
</div>

</div>









<div id="Robots" class="tabcontente boxhight">
  <h3>Robots</h3>

<br><br>

  <div class="wp-editor-container">
<h2><input type="checkbox" class="wp-editor-area" id="noindex" name="add_noindex"  <?php if($noindex!=""){ ?>checked<?php } ?> value="noindex" onclick="noin()"> Robots Meta NOINDEX
</h2>
</div>
<br><br>

 <div class="wp-editor-container">
<h2><input type="checkbox" class="wp-editor-area" id="checkedas1" name="add_nofollow"  <?php if($nofollow!=""){ ?>checked<?php } ?> value="nofollow"> Robots Meta NOFOLLOW
</h2>
</div> 
  
  
</div>











<div id="Advanced" class="tabcontente boxhight">
  <h3>Advanced</h3>
  
  <br><br>
<br><h3>Canonical URL</h3>



<input type="text" class="wp-editor-area" id="parol" name="add_advance" size=100%  onkeyup="parolo()" value="<?php
if($advance==''){//echo esc_url(get_permalink());
}else{    print esc_url($advance);}
?>">
	

  
</div>















<div id="Backlinks" class="tabcontente boxhight">
  <h3>Backlinks</h3>
  
  
  <h3>You need to install backlinks plugin to execute seo.</h3>
  
  
  <h4>Back link is very importent to execute seo on your website and blog. </h4>
  

  
</div>






<div id="analysis" class="tabcontente boxhight">
  <h3>SEO analysis</h3>
  
  <h4>
Analyze free SEO for top search engine rankings.
    ---- <a href='https://plugin.gyrojob.com/gyrojob-seo.php' target='_blank'>SEO Checker</a> -- </h4>
   
   <hr>
   
   <h4>Free Backlink Checker</h4>
   Get a complete backlink profile of your website
    <h4><a href='https://ahrefs.com/backlink-checker' target='_blank'>Backlink Checker</a></h4>
     <hr>
      <h4>Free Backlinks</h4>
      Make free backlinks for your website.
      
       <h4>
       <br>
       <br>Make unlimited backlinks for your website. -- 
    
       </h4>
  
</div>



<br/>
<br/><br/>

<br/>
<br/><br/>
<br/>

</div>

<p  class='lastcol'>&nbsp;</p>

 </div>
 








	
		
	

<p><?php /*
		_e( 'Add a meta description to your HTML code', 'gyrojob-seo' ); ?>. <?php
		_e( 'Character count', 'gyrojob-seo' ); ?>: <span id="gyrojob_seo_output">0</span></p>
		<?php
*/	}











	function save_description( $post_id ){
		if( ! isset( $_POST['gyrojob_description_meta_box_nonce'] ) ){
			return;
		}
		if( ! wp_verify_nonce( sanitize_text_field( wp_unslash($_POST['gyrojob_description_meta_box_nonce'])), 'gyrojob_description_meta_box' ) ){
			return;
		}
		if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if( ! isset( $_POST['add_gyro_description'] ) ){
			return;
		}
		if(empty($_POST['add_title'])){$_POST['add_title']='';}
		if(empty($_POST['add_key'])){$_POST['add_key']='';}

		if(empty($_POST['add_advance'])){$_POST['add_advance']='';}
		if(empty($_POST['add_noindex'])){$_POST['add_noindex']='';}
		if(empty($_POST['add_nofollow'])){$_POST['add_nofollow']='';}

		$title = sanitize_text_field( wp_unslash($_POST['add_title']));
		$description =sanitize_text_field( wp_unslash($_POST['add_gyro_description']));
		$dioi = sanitize_text_field( wp_unslash(	$_POST['add_key']) );
		$advance = sanitize_text_field( wp_unslash(	$_POST['add_advance']) );
		$noindex = sanitize_text_field( wp_unslash(	$_POST['add_noindex']) );
		$nofollow = sanitize_text_field( wp_unslash($_POST['add_nofollow']) );

		if(empty($title)){$title='';}
		if(empty($description)){$description='';}
		if(empty($dioi)){$dioi='';}	
		if(empty($advance)){$advance='';}
        if(empty($noindex)){$noindex='';}
        if(empty($nofollow)){$nofollow='';}

		update_post_meta( $post_id, $this->meta_title, $title );
		update_post_meta( $post_id, $this->meta_description, $description );
		update_post_meta( $post_id, $this->meta_desc, $dioi );
		update_post_meta( $post_id, $this->meta_advance, $advance );
		update_post_meta( $post_id, $this->meta_noindex, $noindex );
		update_post_meta( $post_id, $this->meta_nofollow, $nofollow );
	}














} // class






















class gyrojob_seo_Admin 
{
    private $url = "";
    private $key = "";
    
    
    public function __construct() 
    {
        $this->url = wp_parse_url(get_site_url());
        
        add_action('admin_init', [$this, "redirectseoDashboard"]);
        add_action('admin_menu', [$this, "addseoMenuItems"]);
        add_action( 'admin_head', function() {
            remove_submenu_page( 'index.php', 'gyrojob-seo-network-install-ad-network' );
        } );
       
     //   register_activation_hook(__FILE__, [$this, 'pluginActivated']);
     
     
     
    }
    
    
    
    
    
    
    public function dashboardseoPage() 
    {
       echo("Oops!!! Unable to connect to Dashboard.<br />Please try again later...");
    }

    public function redirectseoDashboard() 
    {
        
        $version = get_option("gyrojobbacklinks_version");
        if (isset($_GET['page']) && $_GET['page'] == 'gyrojob-seo-network-dashboard') {
            // Get key for the dashboard
            $this->getseoDashboardKey();

            // Redirect to external dashboard
            if ($this->key != "failed") {
                wp_redirect("https://plugin.gyrojob.com/backlinks.php?url=" . get_site_url() . "&email=" .get_option('admin_email')."&seo=seo&key=". $this->key."&version=".$version);
                exit;
            }
            else {
                $this->dashboardseoPage();
            }
        }            
            
    }

    public function addseoMenuItems(){
        add_menu_page('Price & Terms','Gyrojob SEO', 'manage_options', 'gyrojob-seo-network-dashboard',[$this, 'dashboardseoPage'],  '');
       
    }  
    
    
    public function getseoDashboardKey()
    { 
        // Try getting dashboard key from server
        $result = wp_remote_post("https://plugin.gyrojob.com/add.php?getKey", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option("admin_email")]]);
        if (!isset($result->errors)) {
            $this->dataseo = json_decode($result["body"]);

            if ($this->dataseo->status == "success") {
                $key = $this->dataseo->key;
                update_option("gyrojob_seo_key", $key, false);
            }
            else {
                // New key not allowed. Using cached key
                $key = get_option("gyrojob_seo_key");        
            }
        } 
        // New key failed
        else {
            $key = "failed";
        }
        
        $this->key = $key;

    }

}























// Start the show
if (!is_admin()) {

}
else {
    $gyrojobseoAdmin = new gyrojob_seo_Admin();
}















?>
