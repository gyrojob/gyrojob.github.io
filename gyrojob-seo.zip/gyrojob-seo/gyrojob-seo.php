<?php
/**
 * Plugin Name: Gyrojob SEO
 * Plugin URI:        https://plugin.gyrojob.com/gyrojob-seo.php
 * Description:       SEO, Organic seo, Image seo, Video seo, web promotion, Google seo with META titles, descriptions tag. optimizes your Wordpress blog for Search Engines (Search Engine Optimization).
 * Version:           1.3.24
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: gyrojob-seo
 */

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}









require_once plugin_dir_path(__FILE__) . 'class-home.php';
if ( ! function_exists( 'Gyrojob_SEO_Meta_Home_Description' ) ) {
new Gyrojob_SEO_Meta_Home_Description();
}


require_once plugin_dir_path(__FILE__) . 'class-post-pages-shop.php';
if ( ! function_exists( 'Gyrojob_SEO_Page_Shop_Description' ) ) {
new Gyrojob_SEO_Page_Shop_Description();
}

require_once plugin_dir_path(__FILE__) . 'class-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Texo_Nomy' ) ) {
new Gyrojob_SEO_Texo_Nomy();
}

require_once plugin_dir_path(__FILE__) . 'class-media.php';
if ( ! function_exists( 'Gyrojob_SEO_Media_Tags' ) ) {
new Gyrojob_SEO_Media_Tags();
}

require_once plugin_dir_path(__FILE__) . 'class-ecommerce-product.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Product' ) ) {
new Gyrojob_SEO_Commerce_Product();
}

require_once plugin_dir_path(__FILE__) . 'class-ecommerce-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Taxo_Nomies' ) ) {
new Gyrojob_SEO_Commerce_Taxo_Nomies();
}













