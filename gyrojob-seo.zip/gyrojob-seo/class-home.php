<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


require_once plugin_dir_path(__FILE__) . 'class-get.php';
if (!is_admin()) {
    $Customvv = new Gyrojob_SEO_Key_file(); 
    $Customvv->gyrojob_seo_setup();
}else{
    
  
}



class Gyrojob_SEO_Meta_Home_Description {

    function __construct() {
        // Add meta fields to the term editing pages
        add_action('admin_menu',  [$this,'gyrojob_seo_add_admin_menu']);
        add_action('admin_init', [$this,'gyrojob_seo_register_settings']);
        add_action('wp_head', [$this,'gyrojob_seo_output_meta_tags']);
     add_action('init', [$this,'gyrojob_seo_update_custom_robots_txt']);
    }

function gyrojob_seo_add_admin_menu() {
    add_options_page(
        'Gyrojob SEO',
        'Gyrojob SEO',
        'manage_options',
        'gyrojob_seo_meta_tags',
        [$this,'gyrojob_seo_options_page']
    );
}




function gyrojob_seo_options_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Gyrojob SEO - Home page meta tags', 'gyrojob-seo'); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('gyrojob_seo_options_group');
            do_settings_sections('gyrojob_seo_meta_tags');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Title', 'gyrojob-seo'); ?></th>
                    <td><input type="text" name="gyrojob_seo_meta_title" value="<?php echo esc_attr(get_option('gyrojob_seo_meta_title')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Description', 'gyrojob-seo'); ?></th>
                    <td><textarea name="gyrojob_seo_meta_description" rows="5" class="large-text"><?php echo esc_textarea(get_option('gyrojob_seo_meta_description')); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Keywords', 'gyrojob-seo'); ?></th>
                    <td><input type="text" name="gyrojob_seo_meta_keywords" value="<?php echo esc_attr(get_option('gyrojob_seo_meta_keywords')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Noindex', 'gyrojob-seo'); ?></th>
                    <td>
                        <label><input type="radio" name="gyrojob_seo_noindex" value="1" <?php checked(1, get_option('gyrojob_seo_noindex')); ?> /> Yes</label>
                        <label><input type="radio" name="gyrojob_seo_noindex" value="0" <?php checked(0, get_option('gyrojob_seo_noindex')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Nofollow', 'gyrojob-seo'); ?></th>
                    <td>
                        <label><input type="radio" name="gyrojob_seo_nofollow" value="1" <?php checked(1, get_option('gyrojob_seo_nofollow')); ?> /> Yes</label>
                        <label><input type="radio" name="gyrojob_seo_nofollow" value="0" <?php checked(0, get_option('gyrojob_seo_nofollow')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Canonical URL', 'gyrojob-seo'); ?></th>
                    <td><input type="text" name="gyrojob_seo_canonical" value="<?php echo esc_attr(get_option('gyrojob_seo_canonical')); ?>" class="regular-text" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php $urlsite='https://plugin.gyrojob.com/process.php'; ?>
        <h1><br><br><br><b><a href="<?php echo esc_url($urlsite); ?>?domain=<?php echo esc_url(get_site_url()).'&seo=seo&email='.esc_html(get_option('admin_email')); ?>">SEO Statistics Dashboard</a></b></h1>
        
    </div>
    <?php
}




    function gyrojob_seo_register_settings() {
    
     $args = array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    );

    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_meta_title', $args);
    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_meta_description', $args);
    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_meta_keywords', $args);

    // For noindex and nofollow, using 'intval' to sanitize as these are expected to be integers (1 or 0)
    $argsnoindex = array(
        'type' => 'integer',
        'sanitize_callback' => 'intval',
        'default' => 0,
    );
    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_noindex',  $argsnoindex);
    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_nofollow', $argsnoindex);

    // Canonical URL should be sanitized using 'esc_url_raw'
    $argscanonical = array(
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => '',
    );
    register_setting('gyrojob_seo_options_group', 'gyrojob_seo_canonical', $argscanonical);
    
    }








function gyrojob_seo_output_meta_tags() {
    if (is_front_page()) {
    
    $value = apply_filters('gyrojob_seo_key_value', 'Initial Value');
    if(empty($value)){$value='';}
    ?>
        
        <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->

        <?php     if (!empty(get_option('gyrojob_seo_meta_title'))) { ?>
        <title><?php echo esc_attr(get_option('gyrojob_seo_meta_title')); ?></title>
       
        <?php  }   if (!empty(get_option('gyrojob_seo_meta_description'))) { ?>
        <meta name="description" content="<?php echo esc_attr(get_option('gyrojob_seo_meta_description')); ?>" />
        <?php }if (!empty(get_option('gyrojob_seo_meta_keywords'))) { ?>
        
        <meta name="keywords" content="<?php echo esc_attr(get_option('gyrojob_seo_meta_keywords')); ?>" />
        
        <?php } if (get_option('gyrojob_seo_noindex')) : ?>
            <meta name="robots" content="noindex" />
        <?php endif; ?>
        <?php if (get_option('gyrojob_seo_nofollow')) : ?>
            <meta name="robots" content="nofollow" />
        <?php endif; ?>
        
        <?php     if (!empty(get_option('gyrojob_seo_canonical'))) { ?>
        <link rel="canonical" href="<?php echo esc_url(get_option('gyrojob_seo_canonical')); ?>" />
        
        
        <meta name="key-site-verification" content="<?php echo esc_html($value); ?>" />
        
        <!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
        
        <?php }
    }
}


 
 
 
 
 
 
 
 
 
 
 
 
 


function gyrojob_seo_update_custom_robots_txt() {


$robots_txt_path = ABSPATH . 'robots.txt';

        // Check if the robots.txt file already exists
        if ( file_exists( $robots_txt_path ) ) {
            return; // Do not overwrite if the file exists
        }

        // Default content for robots.txt
        $robots_content = $this->gyrojob_seo_get_default_robots_content();

        // Write the content to the robots.txt file
        wp_file_put_contents( $robots_txt_path, $robots_content );
        
        
}

 
 
 
     private function gyrojob_seo_get_default_robots_content() {
             $content = "User-agent: *\n";
    $content .= "Disallow: /wp-admin/\n";
    $content .= "Disallow: /wp-includes/\n";
    $content .= "Disallow: /wp-login.php\n";

    $content .= "Sitemap: " . home_url('/sitemap.xml') . "\n";
    
    return     $content;
    
    }
 
 
 
 
 
 
 
 
   
}


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    









