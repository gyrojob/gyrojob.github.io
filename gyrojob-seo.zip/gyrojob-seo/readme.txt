=== Gyrojob SEO ===
Contributors: gyrojob17
Donate link:
Plugin URI: https://plugin.gyrojob.com/gyrojob-seo.php
Author URI: https://plugin.gyrojob.com
Tags: Dofollow backlinks, Domain Authority (DA)
Requires at least: 5.2
Tested up to: 6.7
Stable tag: 1.3.24
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Gyrojob SEO. provide seo services. Allows the modification of META titles, Wordpress blog for Search Engines (Search Engine Optimization).

== Description ==

SEO procedure that makes your website more visible. By building your site the right way and make optimize by our seo expert. You will drive more traffic to your webpages that means more users convert into customers. As a result you will get more sales for your business. We agree to make seo on your website by charging minimum cost. SEO procedure that makes your website more visible. By building your site the right way and make optimize by our seo expert. You will drive more traffic to your webpages that means more users convert into customers. As a result you will get more sales for your business. We agree to make seo on your website by charging minimum cost.

* Nonce Security!
* Generates META tags automatically.
* Works out-of-the-box. Just install!
* You can override any title and set any META description and any META keywords you want!
* Twitter and Facebook customization!
* Quickedit SEO titles and descriptions!
* Import All In One SEO data!
* Supports custom post types!



== External services ==
 This plugin connects to an API to obtain weather information, it's needed to show the weather information and forecasts in the included widget. It sends the user's location every time the widget is loaded (If the location isn't available and/or the user hasn't given their consent, it displays a configurable default location). This service is provided by "PRT Weather INC": [terms of use, privacy policy](https://plugin.gyrojob.com/gyrojob-seo.php#tos)
 
 
 = 3rd party service notice =
This plugin is relying on the free 3rd party "M/s, Gyrojob plugin tools" and sends some of your urls to the service for creating a seo statistics dashboard for you.

[M/s, Gyrojob plugin](https://plugin.gyrojob.com) - [Terms](https://plugin.gyrojob.com/gyrojob-seo.php#tos)




 
= What are the benefits? =
Gyrojob provide SEO for Google, Bing, Yahoo search engine to rank website in first page of search result.

== Frequently Asked Questions ==

Please email gyrojob17@gmail.com with any questions.

Q: How does front page title and description work.

A: The default title and description will be used under settings -> General. If the front page, or blog page are used, then those pages meta information will be used.

= Uninstall plugin? =

Uninstall process removes all SEO process from the all webpages once you remove the plugin via the WordPress Plugins page (not on deactivation).

== Installation ==

== Screenshots ==

This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
This is the second screen shot
== Changelog ==

= 1.3.24 =

The most recent versions.
== Upgrade Notice ==

No Upgrade Notice