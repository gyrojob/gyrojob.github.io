<?php
/**
 * Plugin Name: Custom Meta Tags
 * Plugin URI:        https://plugin.gyrojob.com/gyrojob-seo.php
 * Description:       SEO, Organic seo, Image seo, Video seo, web promotion, Google seo with META titles, descriptions tag. optimizes your Wordpress blog for Search Engines (Search Engine Optimization).
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            gyrojob
 * Author URI:        https://plugin.gyrojob.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: custom-meta-tags
 */

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}






///*

require_once plugin_dir_path(__FILE__) . 'includes/class-home.php';
if ( ! function_exists( 'Gyrojob_SEO_Meta_Home_Description' ) ) {
new Gyrojob_SEO_Meta_Home_Description();
}


require_once plugin_dir_path(__FILE__) . 'includes/class-post-pages-shop.php';
if ( ! function_exists( 'Gyrojob_SEO_Page_Shop_Description' ) ) {
new Gyrojob_SEO_Page_Shop_Description();
}

require_once plugin_dir_path(__FILE__) . 'includes/class-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Texo_Nomy' ) ) {
new Gyrojob_SEO_Texo_Nomy();
}

require_once plugin_dir_path(__FILE__) . 'includes/class-media.php';
if ( ! function_exists( 'Gyrojob_SEO_Media_Tags' ) ) {
new Gyrojob_SEO_Media_Tags();
}

require_once plugin_dir_path(__FILE__) . 'includes/class-ecommerce-product.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Product' ) ) {
new Gyrojob_SEO_Commerce_Product();
}

require_once plugin_dir_path(__FILE__) . 'includes/class-ecommerce-texonomi.php';
if ( ! function_exists( 'Gyrojob_SEO_Commerce_Taxo_Nomies' ) ) {
new Gyrojob_SEO_Commerce_Taxo_Nomies();
}




//add_filter('attachment_fields_to_edit', 'custom_meta_tags_add_fields', 10, 2);

//add_filter('attachment_fields_to_save', 'custom_meta_tags_save_fields', 10, 2);


//    if ( is_attachment() ) {
//*/


















/*

add_action('init', 'aupdate_custom_robots_txt');

function aupdate_custom_robots_txt() {
    $robots_txt_path = ABSPATH . 'robots.txt';

    // Do nothing if the robots.txt file already exists
    if (file_exists($robots_txt_path)) {
        return;
    }

    // Get the custom content from the options
    $robots_content = get_option('robots_txt_content', '');

    // If there's no custom content in the settings, set default content
    // if (empty($robots_content)) {
    $content = "User-agent: *\n";
    $content .= "Disallow: /wp-admin/\n";
    $content .= "Disallow: /wp-includes/\n";
    $content .= "Disallow: /wp-login.php\n";

    $content .= "Sitemap: " . home_url('/sitemap.xml') . "\n";
    
    
    
    // Write the content to the robots.txt file
    file_put_contents($robots_txt_path, $content);
}

*/










/*
//=====================================================ok===============================
function custom_meta_tags_add_meta_box() {
    add_meta_box(
        'custom_meta_tags',
        'Custom Meta Tags',
        'custom_meta_tags_meta_box_callback',
        'attachment',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'custom_meta_tags_add_meta_box');

function custom_meta_tags_meta_box_callback($post) {
    // Retrieve current values of meta tags
    $title = get_post_meta($post->ID, '_custom_meta_title', true);
    $description = get_post_meta($post->ID, '_custom_meta_description', true);
    $keywords = get_post_meta($post->ID, '_custom_meta_keywords', true);
    $noindex = get_post_meta($post->ID, '_custom_meta_noindex', true);
    $nofollow = get_post_meta($post->ID, '_custom_meta_nofollow', true);
    $canonical = get_post_meta($post->ID, '_custom_meta_canonical', true);
    
    // Display meta input fields
    echo '<label for="custom_meta_title">Title</label>';
    echo '<input type="text" id="custom_meta_title" name="custom_meta_title" value="' . esc_attr($title) . '" class="widefat"/>';
    
    echo '<label for="custom_meta_description">Description</label>';
    echo '<textarea id="custom_meta_description" name="custom_meta_description" rows="4" class="widefat">' . esc_textarea($description) . '</textarea>';
    
    echo '<label for="custom_meta_keywords">Keywords</label>';
    echo '<input type="text" id="custom_meta_keywords" name="custom_meta_keywords" value="' . esc_attr($keywords) . '" class="widefat"/>';
    
    echo '<label for="custom_meta_noindex">Noindex</label>';
    echo '<input type="checkbox" id="custom_meta_noindex" name="custom_meta_noindex" ' . checked($noindex, 'on', false) . ' />';
    
    echo '<label for="custom_meta_nofollow">Nofollow</label>';
    echo '<input type="checkbox" id="custom_meta_nofollow" name="custom_meta_nofollow" ' . checked($nofollow, 'on', false) . ' />';
    
    echo '<label for="custom_meta_canonical">Canonical URL</label>';
    echo '<input type="text" id="custom_meta_canonical" name="custom_meta_canonical" value="' . esc_attr($canonical) . '" class="widefat"/>';
}

function custom_meta_tags_save_meta_box_data($post_id) {
    // Check if it's an auto save
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;

    // Check if it's a media item
    if ('attachment' !== get_post_type($post_id)) return $post_id;

    // Save the custom meta fields
    if (isset($_POST['custom_meta_title'])) {
        update_post_meta($post_id, '_custom_meta_title', sanitize_text_field($_POST['custom_meta_title']));
    }
    if (isset($_POST['custom_meta_description'])) {
        update_post_meta($post_id, '_custom_meta_description', sanitize_textarea_field($_POST['custom_meta_description']));
    }
    if (isset($_POST['custom_meta_keywords'])) {
        update_post_meta($post_id, '_custom_meta_keywords', sanitize_text_field($_POST['custom_meta_keywords']));
    }
    if (isset($_POST['custom_meta_noindex'])) {
        update_post_meta($post_id, '_custom_meta_noindex', 'on');
    } else {
        update_post_meta($post_id, '_custom_meta_noindex', '');
    }
    if (isset($_POST['custom_meta_nofollow'])) {
        update_post_meta($post_id, '_custom_meta_nofollow', 'on');
    } else {
        update_post_meta($post_id, '_custom_meta_nofollow', '');
    }
    if (isset($_POST['custom_meta_canonical'])) {
        update_post_meta($post_id, '_custom_meta_canonical', sanitize_text_field($_POST['custom_meta_canonical']));
    }
}
add_action('edit_attachment', 'custom_meta_tags_save_meta_box_data');

function custom_meta_tags_output() {
    if (is_attachment()) {
        global $post;

        // Get custom meta tags for this media
        $title = get_post_meta($post->ID, '_custom_meta_title', true);
        $description = get_post_meta($post->ID, '_custom_meta_description', true);
        $keywords = get_post_meta($post->ID, '_custom_meta_keywords', true);
        $noindex = get_post_meta($post->ID, '_custom_meta_noindex', true);
        $nofollow = get_post_meta($post->ID, '_custom_meta_nofollow', true);
        $canonical = get_post_meta($post->ID, '_custom_meta_canonical', true);

        // Output meta tags
        if ($title) {
            echo '<meta name="title" content="' . esc_attr($title) . '" />' . "\n";
        }
        if ($description) {
            echo '<meta name="description" content="' . esc_attr($description) . '" />' . "\n";
        }
        if ($keywords) {
            echo '<meta name="keywords" content="' . esc_attr($keywords) . '" />' . "\n";
        }
        if ('on' === $noindex) {
            echo '<meta name="robots" content="noindex" />' . "\n";
        }
        if ('on' === $nofollow) {
            echo '<meta name="robots" content="nofollow" />' . "\n";
        }
        if ($canonical) {
            echo '<link rel="canonical" href="' . esc_url($canonical) . '" />' . "\n";
        }
    }
}
add_action('wp_head', 'custom_meta_tags_output');

*/




























/*

// Define the text domain
define( 'CMT_TEXTDOMAIN', 'custom_meta_tags' );

// Add custom fields to the media edit page using `attachment_fields_to_edit`
function cmt_add_meta_tags_fields( $form_fields, $post ) {
    // Retrieve saved meta data for the current attachment
    $meta_title = get_post_meta( $post->ID, '_cmt_media_title', true );
    $meta_description = get_post_meta( $post->ID, '_cmt_media_description', true );
    $meta_keywords = get_post_meta( $post->ID, '_cmt_media_keywords', true );
    $noindex = get_post_meta( $post->ID, '_cmt_media_noindex', true );
    $nofollow = get_post_meta( $post->ID, '_cmt_media_nofollow', true );
    $canonical_url = get_post_meta( $post->ID, '_cmt_media_canonical', true );

    // Add fields to the media edit form
    $form_fields['cmt_media_title'] = array(
        'label' => 'Custom Title',
        'input' => 'text',
        'value' => $meta_title,
        'helps' => 'Enter a custom title for the media item.',
    );

    $form_fields['cmt_media_description'] = array(
        'label' => 'Custom Description',
        'input' => 'textarea',
        'value' => $meta_description,
        'helps' => 'Enter a custom description for the media item.',
    );

    $form_fields['cmt_media_keywords'] = array(
        'label' => 'Custom Keywords',
        'input' => 'text',
        'value' => $meta_keywords,
        'helps' => 'Enter custom keywords for the media item, separated by commas.',
    );

    $form_fields['cmt_media_noindex'] = array(
        'label' => 'Noindex',
        'input' => 'radio',
        'value' => $noindex,
        'options' => array(
            0 => 'No',
            1 => 'Yes',
        ),
        'helps' => 'Select whether to set this media item to "noindex".',
    );

    $form_fields['cmt_media_nofollow'] = array(
        'label' => 'Nofollow',
        'input' => 'radio',
        'value' => $nofollow,
        'options' => array(
            0 => 'No',
            1 => 'Yes',
        ),
        'helps' => 'Select whether to set this media item to "nofollow".',
    );

    $form_fields['cmt_media_canonical'] = array(
        'label' => 'Canonical URL',
        'input' => 'text',
        'value' => $canonical_url,
        'helps' => 'Enter the canonical URL for the media item.',
    );

    return $form_fields;
}
add_filter( 'attachment_fields_to_edit', 'cmt_add_meta_tags_fields', 10, 2 );

// Save custom meta tags when the media item is updated
function cmt_save_meta_tags( $post_id ) {
    // Ensure we only save for media attachments
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }

    // Save the custom fields
    if ( isset( $_POST['attachments'][$post_id]['cmt_media_title'] ) ) {
        update_post_meta( $post_id, '_cmt_media_title', sanitize_text_field( $_POST['attachments'][$post_id]['cmt_media_title'] ) );
    }

    if ( isset( $_POST['attachments'][$post_id]['cmt_media_description'] ) ) {
        update_post_meta( $post_id, '_cmt_media_description', sanitize_textarea_field( $_POST['attachments'][$post_id]['cmt_media_description'] ) );
    }

    if ( isset( $_POST['attachments'][$post_id]['cmt_media_keywords'] ) ) {
        update_post_meta( $post_id, '_cmt_media_keywords', sanitize_text_field( $_POST['attachments'][$post_id]['cmt_media_keywords'] ) );
    }

    if ( isset( $_POST['attachments'][$post_id]['cmt_media_noindex'] ) ) {
        update_post_meta( $post_id, '_cmt_media_noindex', intval( $_POST['attachments'][$post_id]['cmt_media_noindex'] ) );
    }

    if ( isset( $_POST['attachments'][$post_id]['cmt_media_nofollow'] ) ) {
        update_post_meta( $post_id, '_cmt_media_nofollow', intval( $_POST['attachments'][$post_id]['cmt_media_nofollow'] ) );
    }

    if ( isset( $_POST['attachments'][$post_id]['cmt_media_canonical'] ) ) {
        update_post_meta( $post_id, '_cmt_media_canonical', esc_url_raw( $_POST['attachments'][$post_id]['cmt_media_canonical'] ) );
    }

    return $post_id;
}
add_action( 'edit_attachment', 'cmt_save_meta_tags' );

// Output custom meta tags on the frontend
function cmt_output_meta_tags() {
    if ( is_attachment() ) {
        $post_id = get_the_ID();
        $meta_title = get_post_meta( $post_id, '_cmt_media_title', true );
        $meta_description = get_post_meta( $post_id, '_cmt_media_description', true );
        $meta_keywords = get_post_meta( $post_id, '_cmt_media_keywords', true );
        $noindex = get_post_meta( $post_id, '_cmt_media_noindex', true );
        $nofollow = get_post_meta( $post_id, '_cmt_media_nofollow', true );
        $canonical_url = get_post_meta( $post_id, '_cmt_media_canonical', true );

        if ( ! empty( $meta_title ) ) {
            echo '<meta name="title" content="' . esc_attr( $meta_title ) . '">' . "\n";
        }
        if ( ! empty( $meta_description ) ) {
            echo '<meta name="description" content="' . esc_attr( $meta_description ) . '">' . "\n";
        }
        if ( ! empty( $meta_keywords ) ) {
            echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '">' . "\n";
        }
        if ( ! empty( $noindex ) && $noindex == 1 ) {
            echo '<meta name="robots" content="noindex, nofollow">' . "\n";
        }
        if ( ! empty( $canonical_url ) ) {
            echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";
        }
    }
}
add_action( 'wp_head', 'cmt_output_meta_tags' );



*/





































/*

// Define the text domain
define( 'CMT_TEXTDOMAIN', 'custom_meta_tags' );

// Add meta tags fields to media edit page
function cmt_add_meta_tags_fields() {
    ?>
    <div class="postbox">
        <h2><?php _e( 'Custom Meta Tags', CMT_TEXTDOMAIN ); ?></h2>
        <div class="inside">
            <table class="form-table">
                <tr>
                    <th><label for="cmt_media_title"><?php _e( 'Title', CMT_TEXTDOMAIN ); ?></label></th>
                    <td><input type="text" name="cmt_media_title" id="cmt_media_title" value="<?php echo esc_attr( get_post_meta( get_the_ID(), '_cmt_media_title', true ) ); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="cmt_media_description"><?php _e( 'Description', CMT_TEXTDOMAIN ); ?></label></th>
                    <td><textarea name="cmt_media_description" id="cmt_media_description" rows="5" class="large-text"><?php echo esc_textarea( get_post_meta( get_the_ID(), '_cmt_media_description', true ) ); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="cmt_media_keywords"><?php _e( 'Keywords', CMT_TEXTDOMAIN ); ?></label></th>
                    <td><input type="text" name="cmt_media_keywords" id="cmt_media_keywords" value="<?php echo esc_attr( get_post_meta( get_the_ID(), '_cmt_media_keywords', true ) ); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="cmt_media_noindex"><?php _e( 'Noindex', CMT_TEXTDOMAIN ); ?></label></th>
                    <td>
                        <input type="radio" name="cmt_media_noindex" value="1" <?php checked( get_post_meta( get_the_ID(), '_cmt_media_noindex', true ), 1 ); ?> /> <?php _e( 'Yes', CMT_TEXTDOMAIN ); ?>
                        <input type="radio" name="cmt_media_noindex" value="0" <?php checked( get_post_meta( get_the_ID(), '_cmt_media_noindex', true ), 0 ); ?> /> <?php _e( 'No', CMT_TEXTDOMAIN ); ?>
                    </td>
                </tr>
                <tr>
                    <th><label for="cmt_media_nofollow"><?php _e( 'Nofollow', CMT_TEXTDOMAIN ); ?></label></th>
                    <td>
                        <input type="radio" name="cmt_media_nofollow" value="1" <?php checked( get_post_meta( get_the_ID(), '_cmt_media_nofollow', true ), 1 ); ?> /> <?php _e( 'Yes', CMT_TEXTDOMAIN ); ?>
                        <input type="radio" name="cmt_media_nofollow" value="0" <?php checked( get_post_meta( get_the_ID(), '_cmt_media_nofollow', true ), 0 ); ?> /> <?php _e( 'No', CMT_TEXTDOMAIN ); ?>
                    </td>
                </tr>
                <tr>
                    <th><label for="cmt_media_canonical"><?php _e( 'Canonical URL', CMT_TEXTDOMAIN ); ?></label></th>
                    <td><input type="text" name="cmt_media_canonical" id="cmt_media_canonical" value="<?php echo esc_attr( get_post_meta( get_the_ID(), '_cmt_media_canonical', true ) ); ?>" class="regular-text" /></td>
                </tr>
            </table>
        </div>
    </div>
    <?php
}
add_action( 'attachment_submitbox_misc_actions', 'cmt_add_meta_tags_fields' );


// Save the meta tags data when media is updated
function cmt_save_meta_tags( $post_id ) {
    // Check if it's a media attachment
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }

    if ( ! isset( $_POST['attachment_id'] ) || ! isset( $_POST['cmt_media_title'] ) ) {
        return $post_id;
    }

    // Save the custom meta data
    update_post_meta( $post_id, '_cmt_media_title', sanitize_text_field( $_POST['cmt_media_title'] ) );
    update_post_meta( $post_id, '_cmt_media_description', sanitize_textarea_field( $_POST['cmt_media_description'] ) );
    update_post_meta( $post_id, '_cmt_media_keywords', sanitize_text_field( $_POST['cmt_media_keywords'] ) );
    update_post_meta( $post_id, '_cmt_media_noindex', isset( $_POST['cmt_media_noindex'] ) ? intval( $_POST['cmt_media_noindex'] ) : 0 );
    update_post_meta( $post_id, '_cmt_media_nofollow', isset( $_POST['cmt_media_nofollow'] ) ? intval( $_POST['cmt_media_nofollow'] ) : 0 );
    update_post_meta( $post_id, '_cmt_media_canonical', esc_url_raw( $_POST['cmt_media_canonical'] ) );

    return $post_id;
}
add_action( 'save_post_attachment', 'cmt_save_meta_tags' );

// Output custom meta tags on the frontend
function cmt_output_meta_tags() {
    if ( is_attachment() ) {
        $post_id = get_the_ID();
        $meta_title = get_post_meta( $post_id, '_cmt_media_title', true );
        $meta_description = get_post_meta( $post_id, '_cmt_media_description', true );
        $meta_keywords = get_post_meta( $post_id, '_cmt_media_keywords', true );
        $noindex = get_post_meta( $post_id, '_cmt_media_noindex', true );
        $nofollow = get_post_meta( $post_id, '_cmt_media_nofollow', true );
        $canonical_url = get_post_meta( $post_id, '_cmt_media_canonical', true );

        if ( ! empty( $meta_title ) ) {
            echo '<meta name="title" content="' . esc_attr( $meta_title ) . '">' . "\n";
        }
        if ( ! empty( $meta_description ) ) {
            echo '<meta name="description" content="' . esc_attr( $meta_description ) . '">' . "\n";
        }
        if ( ! empty( $meta_keywords ) ) {
            echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '">' . "\n";
        }
        if ( ! empty( $noindex ) && $noindex == 1 ) {
            echo '<meta name="robots" content="noindex, nofollow">' . "\n";
        }
        if ( ! empty( $canonical_url ) ) {
            echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";
        }
    }
}
add_action( 'wp_head', 'cmt_output_meta_tags' );


*/



























/*

// Add custom fields to the Media item edit screen
function custom_meta_tags_add_fields( $form_fields, $post ) {
    // Add Title Field
    $form_fields['custom_meta_title'] = array(
        'label' => __('Meta Title', 'custom_meta_tags'),
        'input' => 'text',
        'value' => get_post_meta($post->ID, '_custom_meta_title', true),
        'helps' => __('Set a custom meta title for this media item.', 'custom_meta_tags'),
    );

    // Add Description Field
    $form_fields['custom_meta_description'] = array(
        'label' => __('Meta Description', 'custom_meta_tags'),
        'input' => 'textarea',
        'value' => get_post_meta($post->ID, '_custom_meta_description', true),
        'helps' => __('Set a custom meta description for this media item.', 'custom_meta_tags'),
    );

    // Add Keywords Field
    $form_fields['custom_meta_keywords'] = array(
        'label' => __('Meta Keywords', 'custom_meta_tags'),
        'input' => 'text',
        'value' => get_post_meta($post->ID, '_custom_meta_keywords', true),
        'helps' => __('Set custom meta keywords for this media item.', 'custom_meta_tags'),
    );

    // Add Noindex Option
    $form_fields['custom_meta_noindex'] = array(
        'label' => __('Noindex', 'custom_meta_tags'),
        'input' => 'html',
        'html' => '<input type="checkbox" name="attachments[' . $post->ID . '][custom_meta_noindex]" value="1"' . (get_post_meta($post->ID, '_custom_meta_noindex', true) ? ' checked' : '') . '>',
        'helps' => __('Check to set noindex for this media item.', 'custom_meta_tags'),
    );

    // Add Nofollow Option
    $form_fields['custom_meta_nofollow'] = array(
        'label' => __('Nofollow', 'custom_meta_tags'),
        'input' => 'html',
        'html' => '<input type="checkbox" name="attachments[' . $post->ID . '][custom_meta_nofollow]" value="1"' . (get_post_meta($post->ID, '_custom_meta_nofollow', true) ? ' checked' : '') . '>',
        'helps' => __('Check to set nofollow for this media item.', 'custom_meta_tags'),
    );

    // Add Canonical Field
    $form_fields['custom_meta_canonical'] = array(
        'label' => __('Canonical URL', 'custom_meta_tags'),
        'input' => 'text',
        'value' => get_post_meta($post->ID, '_custom_meta_canonical', true),
        'helps' => __('Set a canonical URL for this media item.', 'custom_meta_tags'),
    );

    return $form_fields;
}
add_filter('attachment_fields_to_edit', 'custom_meta_tags_add_fields', 10, 2);

// Save custom fields
function custom_meta_tags_save_fields( $post, $attachment ) {
    if ( isset($attachment['custom_meta_title']) ) {
        update_post_meta($post['ID'], '_custom_meta_title', sanitize_text_field($attachment['custom_meta_title']));
    }
    if ( isset($attachment['custom_meta_description']) ) {
        update_post_meta($post['ID'], '_custom_meta_description', sanitize_textarea_field($attachment['custom_meta_description']));
    }
    if ( isset($attachment['custom_meta_keywords']) ) {
        update_post_meta($post['ID'], '_custom_meta_keywords', sanitize_text_field($attachment['custom_meta_keywords']));
    }
    update_post_meta($post['ID'], '_custom_meta_noindex', isset($attachment['custom_meta_noindex']) ? 1 : 0);
    update_post_meta($post['ID'], '_custom_meta_nofollow', isset($attachment['custom_meta_nofollow']) ? 1 : 0);
    if ( isset($attachment['custom_meta_canonical']) ) {
        update_post_meta($post['ID'], '_custom_meta_canonical', esc_url_raw($attachment['custom_meta_canonical']));
    }

    return $post;
}
add_filter('attachment_fields_to_save', 'custom_meta_tags_save_fields', 10, 2);

// Add custom meta tags to the frontend output (if needed)
function custom_meta_tags_output() {
    if ( is_attachment() ) {
        global $post;

        $title = get_post_meta($post->ID, '_custom_meta_title', true);
        $description = get_post_meta($post->ID, '_custom_meta_description', true);
        $keywords = get_post_meta($post->ID, '_custom_meta_keywords', true);
        $noindex = get_post_meta($post->ID, '_custom_meta_noindex', true);
        $nofollow = get_post_meta($post->ID, '_custom_meta_nofollow', true);
        $canonical = get_post_meta($post->ID, '_custom_meta_canonical', true);

        if ( $title ) {
            echo '<meta name="title" content="' . esc_attr($title) . '">' . "\n";
        }
        if ( $description ) {
            echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
        }
        if ( $keywords ) {
            echo '<meta name="keywords" content="' . esc_attr($keywords) . '">' . "\n";
        }
        if ( $noindex ) {
            echo '<meta name="robots" content="noindex' . ($nofollow ? ',nofollow' : '') . '">' . "\n";
        } elseif ( $nofollow ) {
            echo '<meta name="robots" content="nofollow">' . "\n";
        }
        if ( $canonical ) {
            echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
        }
    }
}
add_action('wp_head', 'custom_meta_tags_output');





*/























/*


function cmt_add_admin_menu() {
    add_options_page(
        'Custom Meta Tags',
        'Custom Meta Tags',
        'manage_options',
        'custom_meta_tags',
        'cmt_options_page'
    );
}
add_action('admin_menu', 'cmt_add_admin_menu');



function cmt_options_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Custom Meta Tags', 'custom_meta_tags'); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('cmt_options_group');
            do_settings_sections('custom_meta_tags');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Title', 'custom_meta_tags'); ?></th>
                    <td><input type="text" name="cmt_meta_title" value="<?php echo esc_attr(get_option('cmt_meta_title')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Description', 'custom_meta_tags'); ?></th>
                    <td><textarea name="cmt_meta_description"><?php echo esc_textarea(get_option('cmt_meta_description')); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Keywords', 'custom_meta_tags'); ?></th>
                    <td><input type="text" name="cmt_meta_keywords" value="<?php echo esc_attr(get_option('cmt_meta_keywords')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Noindex', 'custom_meta_tags'); ?></th>
                    <td>
                        <label><input type="radio" name="cmt_noindex" value="1" <?php checked(1, get_option('cmt_noindex')); ?> /> Yes</label>
                        <label><input type="radio" name="cmt_noindex" value="0" <?php checked(0, get_option('cmt_noindex')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Nofollow', 'custom_meta_tags'); ?></th>
                    <td>
                        <label><input type="radio" name="cmt_nofollow" value="1" <?php checked(1, get_option('cmt_nofollow')); ?> /> Yes</label>
                        <label><input type="radio" name="cmt_nofollow" value="0" <?php checked(0, get_option('cmt_nofollow')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Canonical URL', 'custom_meta_tags'); ?></th>
                    <td><input type="text" name="cmt_canonical" value="<?php echo esc_attr(get_option('cmt_canonical')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}




function cmt_register_settings() {
    

    
     $args = array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',
    );

    register_setting('cmt_options_group', 'cmt_meta_title', $args);
    register_setting('cmt_options_group', 'cmt_meta_description', $args);
    register_setting('cmt_options_group', 'cmt_meta_keywords', $args);

    // For noindex and nofollow, using 'intval' to sanitize as these are expected to be integers (1 or 0)
    $args_noindex = array(
        'type' => 'integer',
        'sanitize_callback' => 'intval',
        'default' => 0,
    );
    register_setting('cmt_options_group', 'cmt_noindex', $args_noindex);
    register_setting('cmt_options_group', 'cmt_nofollow', $args_noindex);

    // Canonical URL should be sanitized using 'esc_url_raw'
    $args_canonical = array(
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => '',
    );
    register_setting('cmt_options_group', 'cmt_canonical', $args_canonical);
    
    
    
    
    
    
    
    
    
    
    
}
add_action('admin_init', 'cmt_register_settings');







function cmt_output_meta_tags() {
    if (is_front_page()) {
        ?>
        <title><?php echo esc_attr(get_option('cmt_meta_title')); ?></title>
        <meta name="description" content="<?php echo esc_attr(get_option('cmt_meta_description')); ?>" />
        <meta name="keywords" content="<?php echo esc_attr(get_option('cmt_meta_keywords')); ?>" />
        <?php if (get_option('cmt_noindex')) : ?>
            <meta name="robots" content="noindex" />
        <?php endif; ?>
        <?php if (get_option('cmt_nofollow')) : ?>
            <meta name="robots" content="nofollow" />
        <?php endif; ?>
        <link rel="canonical" href="<?php echo esc_url(get_option('cmt_canonical')); ?>" />
        <?php
    }
}
add_action('wp_head', 'cmt_output_meta_tags','');



*/





























