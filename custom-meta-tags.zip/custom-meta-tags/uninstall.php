<?php

// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
 
gyrojob_seo_meta_tags_handle_site();

if( is_multisite() ){
	
	// wordpress 4.6
	if( function_exists( 'get_sites' ) && class_exists( 'WP_Site_Query' ) ) {
		$sites = get_sites();
		foreach( $sites as $site ){
			switch_to_blog( $site->blog_id );
			gyrojob_seo_meta_tags_handle_site();
		}
	}
	else{
		
		// wordpress < 4.6
		if( function_exists( 'get_sites' ) ) {
			$sites = get_sites();
			foreach ( $sites as $site ) {
				switch_to_blog( $site['blog_id'] );
				gyrojob_seo_meta_tags_handle_site();
			}
		}
	}
}















function gyrojob_seo_meta_tags_handle_site(){
    
    
    
    
    
    
        $file_path = ABSPATH . 'robots.txt';
    if ( file_exists( $file_path ) ) {
        unlink( $file_path );
    }
    
    
    
    
    
    
    
    
	// drop option
	delete_option( 'gyrojob_seo_meta_title' );
	delete_option( 'gyrojob_seo_meta_description' );
	delete_option( 'gyrojob_seo_meta_keywords' );
	delete_option( 'gyrojob_seo_noindex' );
	delete_option( 'gyrojob_seo_nofollow' );
	delete_option( 'gyrojob_seo_canonical' );
	
	
	
	// drop post meta
	delete_post_meta_by_key( '_gyrojob_seo_post_meta_title' );	
	delete_post_meta_by_key( '_cmtgyrojob_seo_post_meta_description' );
	delete_post_meta_by_key( '_gyrojob_seo_post_meta_keywords' );
	delete_post_meta_by_key( '_gyrojob_seo_post_meta_noindex' );
	delete_post_meta_by_key( '_gyrojob_seo_post_meta_nofollow' );
	delete_post_meta_by_key( '_gyrojob_seo_post_meta_canonical' );
	
	
		// drop taxonomy meta
	delete_post_meta_by_key( '_gyrojob_seo_meta_title' );	
	delete_post_meta_by_key( '_gyrojob_seo_meta_description' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_keywords' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_noindex' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_nofollow' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_canonical' );
	
	
				// drop woo media meta
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_title' );	
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_description' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_keywords' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_noindex' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_nofollow' );
	delete_post_meta_by_key( '_gyrojob_seo_meta_media_canonical' );
	
	
	
	
			// woo product meta
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_title' );	
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_description' );
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_keywords' );
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_noindex' );
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_nofollow' );
	delete_post_meta_by_key( '_gyrojob_seo_product_meta_canonical' );

	
			// drop woo taxonomy meta
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_title' );	
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_description' );
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_keywords' );
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_noindex' );
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_nofollow' );
	delete_post_meta_by_key( '_gyrojob_seo_woo_texonomi_meta_canonical' );
	                          
	
	
	
}
 
 

?>