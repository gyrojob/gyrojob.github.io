<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



         

         

class Gyrojob_SEO_Commerce_Taxo_Nomies {

    public function __construct() {
        // Add fields to WooCommerce taxonomies
        add_action( 'product_cat_add_form_fields', [ $this, 'gyrojob_seo_add_taxonomy_fields' ] );
        add_action( 'product_cat_edit_form_fields', [ $this, 'gyrojob_seo_edit_taxonomy_fields' ] );
        add_action( 'product_tag_add_form_fields', [ $this, 'gyrojob_seo_add_taxonomy_fields' ] );
        add_action( 'product_tag_edit_form_fields', [ $this, 'gyrojob_seo_edit_taxonomy_fields' ] );

        // Save taxonomy meta fields
        add_action( 'edited_product_cat', [ $this, 'gyrojob_seo_save_taxonomy_meta' ] );
        add_action( 'create_product_cat', [ $this, 'gyrojob_seo_save_taxonomy_meta' ] );
        add_action( 'edited_product_tag', [ $this, 'gyrojob_seo_save_taxonomy_meta' ] );
        add_action( 'create_product_tag', [ $this, 'gyrojob_seo_save_taxonomy_meta' ] );

        // Output meta tags on taxonomy pages
        add_action( 'wp_head', [ $this, 'gyrojob_seo_output_taxonomy_meta' ] );
    }

    public function gyrojob_seo_add_taxonomy_fields() {
        

        wp_nonce_field( 'gyrojob_seo_save_taxonomy_meta', 'gyrojob_seo_meta_tagstc_nonce' );
        
        ?>
        <div class="form-field">
            <label for="meta_title"><h1><b>Gyrojob SEO</b></h1></label>
        </div>
        <div class="form-field">
            <label for="meta_title">Meta Title</label>
            <input type="text" name="meta_title" id="meta_title" value="" />
        </div>
        <div class="form-field">
            <label for="meta_description">Meta Description</label>
            <textarea name="meta_description" id="meta_description"></textarea>
        </div>
        <div class="form-field">
            <label for="meta_keywords">Meta Keywords</label>
            <input type="text" name="meta_keywords" id="meta_keywords" value="" />
        </div>
        <div class="form-field">
            <label>Noindex</label>
            <input type="radio" name="meta_noindex" value="1"> Noindex
            <input type="radio" name="meta_noindex" value="0" checked> Index
        </div>
        <div class="form-field">
            <label>Nofollow</label>
            <input type="radio" name="meta_nofollow" value="1"> Nofollow
            <input type="radio" name="meta_nofollow" value="0" checked> Follow
        </div>
        <div class="form-field">
            <label for="meta_canonical">Canonical URL</label>
            <input type="text" name="meta_canonical" id="meta_canonical" value="" />
        </div>
        <?php
    }

    public function gyrojob_seo_edit_taxonomy_fields( $term ) {
        
            // Add a nonce field.
        wp_nonce_field( 'gyrojob_seo_save_taxonomy_meta', 'gyrojob_seo_meta_tagstc_nonce' );
    

        $meta_title = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_title', true );
        $meta_description = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_description', true );
        $meta_keywords = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_keywords', true );
        $meta_noindex = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_noindex', true );
        $meta_nofollow = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_nofollow', true );
        $meta_canonical = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_canonical', true );

        ?>
        <div class="form-field">
            <th scope="row"><label for="meta_title"><h1><b>Gyrojob SEO</b></h1></label></th>
        </div>
        <tr class="form-field">
            <th scope="row"><label for="meta_title">Meta Title</label></th>
            <td><input type="text" name="meta_title" id="meta_title" value="<?php echo esc_attr( $meta_title ); ?>" /></td>
        </tr>
        <tr class="form-field">
            <th scope="row"><label for="meta_description">Meta Description</label></th>
            <td><textarea name="meta_description" id="meta_description"><?php echo esc_textarea( $meta_description ); ?></textarea></td>
        </tr>
        <tr class="form-field">
            <th scope="row"><label for="meta_keywords">Meta Keywords</label></th>
            <td><input type="text" name="meta_keywords" id="meta_keywords" value="<?php echo esc_attr( $meta_keywords ); ?>" /></td>
        </tr>
        <tr class="form-field">
            <th scope="row">Noindex</th>
            <td>
                <input type="radio" name="meta_noindex" value="1" <?php checked( $meta_noindex, '1' ); ?>> Noindex
                <input type="radio" name="meta_noindex" value="0" <?php checked( $meta_noindex, '0' ); ?> checked> Index
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row">Nofollow</th>
            <td>
                <input type="radio" name="meta_nofollow" value="1" <?php checked( $meta_nofollow, '1' ); ?>> Nofollow
                <input type="radio" name="meta_nofollow" value="0" <?php checked( $meta_nofollow, '0' ); ?> checked> Follow
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row"><label for="meta_canonical">Canonical URL</label></th>
            <td><input type="text" name="meta_canonical" id="meta_canonical" value="<?php echo esc_attr( $meta_canonical ); ?>" /></td>
        </tr>
        <?php
    }

    public function gyrojob_seo_save_taxonomy_meta( $term_id ) {
        
            // Verify nonce.
    if ( ! isset( $_POST['gyrojob_seo_meta_tagstc_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_tagstc_nonce'])), 'gyrojob_seo_save_taxonomy_meta' ) ) {
        return;
    }
        
        
    if(empty($_POST['meta_title'])){$_POST['meta_title']='';}    
    if(empty($_POST['meta_description'])){$_POST['meta_description']='';}
    if(empty($_POST['meta_keywords'])){$_POST['meta_keywords']='';}
    if(empty($_POST['meta_noindex'])){$_POST['meta_noindex']='';}
    if(empty($_POST['meta_nofollow'])){$_POST['meta_nofollow']='';}
    if(empty($_POST['meta_canonical'])){$_POST['meta_canonical']='';}
        
        
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_title', sanitize_text_field(wp_unslash( $_POST['meta_title']) ) );
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_description', sanitize_textarea_field(wp_unslash( $_POST['meta_description']) ) );
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_keywords', sanitize_text_field(wp_unslash( $_POST['meta_keywords']) ) );
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_noindex', sanitize_text_field(wp_unslash( $_POST['meta_noindex']) ) );
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_nofollow', sanitize_text_field(wp_unslash( $_POST['meta_nofollow']) ) );
        update_term_meta( $term_id, '_gyrojob_seo_woo_texonomi_meta_canonical', esc_url_raw(wp_unslash( $_POST['meta_canonical']) ) );
    }

    public function gyrojob_seo_output_taxonomy_meta() {
        if ( is_tax( array( 'product_cat', 'product_tag' ) ) ) {
            $term = get_queried_object();

            $meta_title = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_title', true );
            $meta_description = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_description', true );
            $meta_keywords = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_keywords', true );
            $meta_noindex = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_noindex', true );
            $meta_nofollow = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_nofollow', true );
            $meta_canonical = get_term_meta( $term->term_id, '_gyrojob_seo_woo_texonomi_meta_canonical', true );
            ?>
            
            <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
            
            <?php

            if ( $meta_title ) {
                echo '<title>' . esc_html( $meta_title ) . '</title>' . "\n";
            }

            if ( $meta_description ) {
                echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
            }

            if ( $meta_keywords ) {
                echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '" />' . "\n";
            }

            if ( $meta_noindex === '1' ) {
                echo '<meta name="robots" content="noindex' . ( $meta_nofollow === '1' ? ', nofollow' : '' ) . '" />' . "\n";
            } elseif ( $meta_nofollow === '1' ) {
                echo '<meta name="robots" content="nofollow" />' . "\n";
            }

            if ( $meta_canonical ) {
                echo '<link rel="canonical" href="' . esc_url( $meta_canonical ) . '" />' . "\n";
            }
            ?>
            
            <!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
            
            <?php
        }
    }
}




















