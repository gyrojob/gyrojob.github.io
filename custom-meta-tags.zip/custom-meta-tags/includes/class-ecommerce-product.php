<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Gyrojob_SEO_Commerce_Product {

    public function __construct() {
        // Add meta box for WooCommerce product pages
        add_action( 'add_meta_boxes', [ $this, 'gyrojob_seo_add_meta_box' ] );
        
        // Save meta box data
        add_action( 'save_post', [ $this, 'gyrojob_seo_save_meta_box_product_data' ] );
        
        // Output meta tags on the front end
        add_action( 'wp_head', [ $this, 'gyrojob_seo_output_meta_tags' ] );
    }

    public function gyrojob_seo_add_meta_box() {
        add_meta_box(
            'gyrojob_seo_meta_tags',
            'Gyrojob SEO',
            [ $this, 'gyrojob_seo_render_meta_box' ],
            'product',
            'normal',
            'high'
        );
    }

    public function gyrojob_seo_render_meta_box( $post ) {
        // Add a nonce field
        wp_nonce_field( 'gyrojob_seo_save_meta_box_product_data', 'gyrojob_seo_meta_tags_nonce' );

        $meta_title = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_title', true );
        $meta_description = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_description', true );
        $meta_keywords = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_keywords', true );
        $meta_noindex = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_noindex', true );
        $meta_nofollow = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_nofollow', true );
        $meta_canonical = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_canonical', true );

        ?>
        <p>
            <label for="meta_title"> Meta Title: </label>
            <input type="text" id="meta_title" name="meta_title" value="<?php echo esc_attr( $meta_title ); ?>" class="widefat" />
        </p>
        <p>
            <label for="meta_description"> Meta Description: </label>
            <textarea id="meta_description" name="meta_description" class="widefat"><?php echo esc_textarea( $meta_description ); ?></textarea>
        </p>
        <p>
            <label for="meta_keywords"> Meta Keywords: </label>
            <input type="text" id="meta_keywords" name="meta_keywords" value="<?php echo esc_attr( $meta_keywords ); ?>" class="widefat" />
        </p>
        <p>
            <label>
                <input type="radio" name="meta_noindex" value="1" <?php checked( $meta_noindex, '1' ); ?> /> Noindex
            </label>
            <label>
                <input type="radio" name="meta_noindex" value="0" <?php checked( $meta_noindex, '0' ); ?> checked/> Index
            </label>
        </p>
        <p>
            <label>
                <input type="radio" name="meta_nofollow" value="1" <?php checked( $meta_nofollow, '1' ); ?> /> Nofollow
            </label>
            <label>
                <input type="radio" name="meta_nofollow" value="0" <?php checked( $meta_nofollow, '0' ); ?> checked/> Follow
            </label>
        </p>
        <p>
            <label for="meta_canonical"> Canonical URL: </label>
            <input type="text" id="meta_canonical" name="meta_canonical" value="<?php echo esc_attr( $meta_canonical ); ?>" class="widefat" />
        </p>
        <?php
    }

    public function gyrojob_seo_save_meta_box_product_data( $post_id ) {
        // Verify nonce
        if ( ! isset( $_POST['gyrojob_seo_meta_tags_nonce'] ) || ! wp_verify_nonce(sanitize_textarea_field(wp_unslash( $_POST['gyrojob_seo_meta_tags_nonce'])), 'gyrojob_seo_save_meta_box_product_data' ) ) {
            return;
        }

        // Check autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check user permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }


        if (!isset($_POST['meta_title'])) return;
        if (!isset($_POST['meta_description'])) return;
        if (!isset($_POST['meta_keywords'])) return;
        if (!isset($_POST['meta_noindex'])) return;
        if (!isset($_POST['meta_nofollow'])) return;
        if (!isset($_POST['meta_canonical'])) return;
        
        
        // Save meta data
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_title', sanitize_text_field(wp_unslash( $_POST['meta_title']) ) );
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_description', sanitize_textarea_field(wp_unslash( $_POST['meta_description']) ) );
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_keywords', sanitize_text_field(wp_unslash( $_POST['meta_keywords']) ) );
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_noindex', sanitize_text_field(wp_unslash( $_POST['meta_noindex']) ) );
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_nofollow', sanitize_text_field(wp_unslash( $_POST['meta_nofollow']) ) );
        update_post_meta( $post_id, '_gyrojob_seo_product_meta_canonical', esc_url_raw(wp_unslash( $_POST['meta_canonical']) ) );
    }

    public function gyrojob_seo_output_meta_tags() {
        if ( is_singular( 'product' ) ) {
            global $post;

            $meta_title = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_title', true );
            $meta_description = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_description', true );
            $meta_keywords = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_keywords', true );
            $meta_noindex = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_noindex', true );
            $meta_nofollow = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_nofollow', true );
            $meta_canonical = get_post_meta( $post->ID, '_gyrojob_seo_product_meta_canonical', true );
            ?>
            
            <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
                    
            <?php
            
            if ( $meta_title ) {
                echo '<title>' . esc_html( $meta_title ) . '</title>' . "\n";
            }

            if ( $meta_description ) {
                echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
            }

            if ( $meta_keywords ) {
                echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '" />' . "\n";
            }

            if ( $meta_noindex === '1' ) {
                echo '<meta name="robots" content="noindex' . ( $meta_nofollow === '1' ? ', nofollow' : '' ) . '" />' . "\n";
            } elseif ( $meta_nofollow === '1' ) {
                echo '<meta name="robots" content="nofollow" />' . "\n";
            }

            if ( $meta_canonical ) {
                echo '<link rel="canonical" href="' . esc_url( $meta_canonical ) . '" />' . "\n";
            }
            ?>
            
            <!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
            
            <?php
        }
    }
}







