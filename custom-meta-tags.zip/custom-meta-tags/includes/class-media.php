<?php




class Gyrojob_SEO_Media_Tags {

    // Constructor
    public function __construct() {
        // Add custom fields to media items
        add_action('add_meta_boxes', array($this, 'gyrojob_seo_add_meta_box'));

        // Save the custom meta data
        add_action('edit_attachment', array($this, 'gyrojob_seo_save_meta_box_data'));

        // Output custom meta tags in the head
        add_action('wp_head', array($this, 'gyrojob_seo_output_meta_tags'));
    }

    // Add the meta box for media items
    public function gyrojob_seo_add_meta_box() {
        add_meta_box(
            'custom_meta_tags',
            'Gyrojob SEO',
            array($this, 'gyrojob_seo_meta_box_callback'),
            'attachment',
            'normal',
            'high'
        );
    }

    // Callback function for the meta box
    public function gyrojob_seo_meta_box_callback($post) {
        
        // Add a nonce field
        wp_nonce_field( 'gyrojob_seo_save_meta_box_data', 'gyrojob_seo_meta_media_tags_nonce' );

        // Retrieve current values of meta tags
        $title = get_post_meta($post->ID, '_gyrojob_seo_meta_media_title', true);
        $description = get_post_meta($post->ID, '_gyrojob_seo_meta_media_description', true);
        $keywords = get_post_meta($post->ID, '_gyrojob_seo_meta_media_keywords', true);
        $noindex = get_post_meta($post->ID, '_gyrojob_seo_meta_media_noindex', true);
        $nofollow = get_post_meta($post->ID, '_gyrojob_seo_meta_media_nofollow', true);
        $canonical = get_post_meta($post->ID, '_gyrojob_seo_meta_media_canonical', true);

        // Display meta input fields
        echo '<label for="gyrojob_seo_meta_media_title">Title</label>';
        echo '<input type="text" id="gyrojob_seo_meta_media_title" name="gyrojob_seo_meta_media_title" value="' . esc_attr($title) . '" class="widefat"/>';
        
        echo '<label for="gyrojob_seo_meta_media_description">Description</label>';
        echo '<textarea id="gyrojob_seo_meta_media_description" name="gyrojob_seo_meta_media_description" rows="4" class="widefat">' . esc_textarea($description) . '</textarea>';
        
        echo '<label for="gyrojob_seo_meta_media_keywords">Keywords</label>';
        echo '<input type="text" id="gyrojob_seo_meta_media_keywords" name="gyrojob_seo_meta_media_keywords" value="' . esc_attr($keywords) . '" class="widefat"/>';
        
        echo '<label for="gyrojob_seo_meta_media_noindex"><br><br>Noindex &nbsp;&nbsp;</label>';
        echo '<input type="checkbox" id="gyrojob_seo_meta_media_noindex" name="gyrojob_seo_meta_media_noindex" ' . checked($noindex, 'on', false) . ' />';
        
        echo '<label for="gyrojob_seo_meta_media_nofollow"><br><br>Nofollow&nbsp;&nbsp;</label>';
        echo '<input type="checkbox" id="gyrojob_seo_meta_media_nofollow" name="gyrojob_seo_meta_media_nofollow" ' . checked($nofollow, 'on', false) . ' />';
        
        echo '<label for="gyrojob_seo_meta_media_canonical"><br><br>Canonical URL</label>';
        echo '<input type="text" id="gyrojob_seo_meta_media_canonical" name="gyrojob_seo_meta_media_canonical" value="' . esc_attr($canonical) . '" class="widefat"/>';
    }

    // Save the custom meta data
    public function gyrojob_seo_save_meta_box_data($post_id) {
        
        // Verify nonce
        if ( ! isset( $_POST['gyrojob_seo_meta_media_tags_nonce'] ) || ! wp_verify_nonce(sanitize_textarea_field(wp_unslash( $_POST['gyrojob_seo_meta_media_tags_nonce'])), 'gyrojob_seo_save_meta_box_data' ) ) {
            return;
        }

        // Check if it's an auto save
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;

        // Check if it's a media item
        if ('attachment' !== get_post_type($post_id)) return $post_id;

        // Save the custom meta fields
        if (isset($_POST['gyrojob_seo_meta_media_title'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_title', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_media_title'])));
        }
        if (isset($_POST['gyrojob_seo_meta_media_description'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_description', sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_media_description'])));
        }
        if (isset($_POST['gyrojob_seo_meta_media_keywords'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_keywords', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_media_keywords'])));
        }
        if (isset($_POST['gyrojob_seo_meta_media_noindex'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_noindex', 'on');
        } else {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_noindex', '');
        }
        if (isset($_POST['gyrojob_seo_meta_media_nofollow'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_nofollow', 'on');
        } else {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_nofollow', '');
        }
        if (isset($_POST['gyrojob_seo_meta_media_canonical'])) {
            update_post_meta($post_id, '_gyrojob_seo_meta_media_canonical', sanitize_text_field(wp_unslash($_POST['gyrojob_seo_meta_media_canonical'])));
        }
    }

    // Output custom meta tags on the front-end
    public function gyrojob_seo_output_meta_tags() {
        if (is_attachment()) {
            global $post;

            // Get custom meta tags for this media
            $title = get_post_meta($post->ID, '_gyrojob_seo_meta_media_title', true);
            $description = get_post_meta($post->ID, '_gyrojob_seo_meta_media_description', true);
            $keywords = get_post_meta($post->ID, '_gyrojob_seo_meta_media_keywords', true);
            $noindex = get_post_meta($post->ID, '_gyrojob_seo_meta_media_noindex', true);
            $nofollow = get_post_meta($post->ID, '_gyrojob_seo_meta_media_nofollow', true);
            $canonical = get_post_meta($post->ID, '_gyrojob_seo_meta_media_canonical', true);

            // Output meta tags
            if ($title) {
                echo '<meta name="title" content="' . esc_attr($title) . '" />' . "\n";
            }
            if ($description) {
                echo '<meta name="description" content="' . esc_attr($description) . '" />' . "\n";
            }
            if ($keywords) {
                echo '<meta name="keywords" content="' . esc_attr($keywords) . '" />' . "\n";
            }
            if ('on' === $noindex) {
                echo '<meta name="robots" content="noindex" />' . "\n";
            }
            if ('on' === $nofollow) {
                echo '<meta name="robots" content="nofollow" />' . "\n";
            }
            if ($canonical) {
                echo '<link rel="canonical" href="' . esc_url($canonical) . '" />' . "\n";
            }
        }
    }
}


/*
// Instantiate the class
if (class_exists('Custom_Meta_Tags')) {
    $custom_meta_tags = new Custom_Meta_Tags();
}

*/



