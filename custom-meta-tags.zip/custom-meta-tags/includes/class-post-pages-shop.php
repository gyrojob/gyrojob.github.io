<?php

// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class Gyrojob_SEO_Page_Shop_Description {

    public function __construct() {
        add_action('add_meta_boxes', [$this, 'gyrojob_seo_meta_boxes']);
        add_action('save_post', [$this, 'gyrojob_seo_save_meta_box_data']);
        add_action('wp_head', [$this, 'gyrojob_seo_output_meta_tags']);
        //add_action('admin_menu', [$this, 'add_shop_meta_settings']);
    }

    public function gyrojob_seo_meta_boxes() {
        add_meta_box(
            'gyrojob_seo_meta_tags_meta_box',
            'Gyrojob SEO',
            [$this, 'gyrojob_seo_render_meta_box'],
            ['post', 'page'],
            'normal',
            'high'
        );
    }

    public function gyrojob_seo_render_meta_box($post) {
                // Add a nonce field.
        wp_nonce_field( 'gyrojob_seo_save_meta_box_data', 'gyrojob_seo_meta_post_page_nonce' );
        
        $meta_title = get_post_meta($post->ID,             '_gyrojob_seo_post_meta_title', true);
        $meta_description = get_post_meta($post->ID, '_gyrojob_seo_post_meta_description', true);
        $meta_keywords = get_post_meta($post->ID,       '_gyrojob_seo_post_meta_keywords', true);
        $meta_noindex = get_post_meta($post->ID,         '_gyrojob_seo_post_meta_noindex', true);
        $meta_nofollow = get_post_meta($post->ID,       '_gyrojob_seo_post_meta_nofollow', true);
        $meta_canonical = get_post_meta($post->ID,     '_gyrojob_seo_post_meta_canonical', true);
        ?>
        <table class="form-table">
            <tr>
                <th><label for="meta_title">Title</label></th>
                <td><input type="text" name="meta_title" id="meta_title" value="<?php echo esc_attr($meta_title); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th><label for="meta_description">Description</label></th>
                <td><textarea name="meta_description" id="meta_description" class="large-text"><?php echo esc_textarea($meta_description); ?></textarea></td>
            </tr>
            <tr>
                <th><label for="meta_keywords">Keywords</label></th>
                <td><input type="text" name="meta_keywords" id="meta_keywords" value="<?php echo esc_attr($meta_keywords); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th>Noindex</th>
                <td>
                    <label><input type="radio" name="meta_noindex" value="1" <?php checked($meta_noindex, '1'); ?>> Yes</label>
                    <label><input type="radio" name="meta_noindex" value="0" <?php checked($meta_noindex, '0'); ?> checked> No</label>
                </td>
            </tr>
            <tr>
                <th>Nofollow</th>
                <td>
                    <label><input type="radio" name="meta_nofollow" value="1" <?php checked($meta_nofollow, '1'); ?>> Yes</label>
                    <label><input type="radio" name="meta_nofollow" value="0" <?php checked($meta_nofollow, '0'); ?> checked> No</label>
                </td>
            </tr>
            <tr>
                <th><label for="meta_canonical">Canonical URL</label></th>
                <td><input type="text" name="meta_canonical" id="meta_canonical" value="<?php echo esc_attr($meta_canonical); ?>" class="regular-text"></td>
            </tr>
        </table>
        <?php
    }

    public function gyrojob_seo_save_meta_box_data($post_id) {
        // Verify nonce.
    if ( ! isset( $_POST['gyrojob_seo_meta_post_page_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['gyrojob_seo_meta_post_page_nonce'])), 'gyrojob_seo_save_meta_box_data' ) ) {
        return;
    }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!isset($_POST['meta_title'])) return;
        if (!isset($_POST['meta_description'])) return;
        if (!isset($_POST['meta_keywords'])) return;
        if (!isset($_POST['meta_canonical'])) return;
        
        update_post_meta($post_id, '_gyrojob_seo_post_meta_title', sanitize_text_field(wp_unslash($_POST['meta_title'])));
        update_post_meta($post_id, '_gyrojob_seo_post_meta_description', sanitize_textarea_field(wp_unslash($_POST['meta_description'])));
        update_post_meta($post_id, '_gyrojob_seo_post_meta_keywords', sanitize_text_field(wp_unslash($_POST['meta_keywords'])));
        update_post_meta($post_id, '_gyrojob_seo_post_meta_noindex', isset($_POST['meta_noindex']) ? sanitize_text_field(wp_unslash($_POST['meta_noindex'])) : '');
        update_post_meta($post_id, '_gyrojob_seo_post_meta_nofollow', isset($_POST['meta_nofollow']) ? sanitize_text_field(wp_unslash($_POST['meta_nofollow'])) : '');
        update_post_meta($post_id, '_gyrojob_seo_post_meta_canonical', esc_url_raw(wp_unslash($_POST['meta_canonical'])));
    }

    public function gyrojob_seo_output_meta_tags() {
        if (is_singular(['post', 'page']) || (function_exists('is_shop') && is_shop())) {
            $post_id = is_singular() ? get_queried_object_id() : null;
            if (function_exists('is_shop') && is_shop()) {
                $post_id = get_option('woocommerce_shop_page_id');
            }

            $meta_title = get_post_meta($post_id, '_gyrojob_seo_post_meta_title', true);
            $meta_description = get_post_meta($post_id, '_gyrojob_seo_post_meta_description', true);
            $meta_keywords = get_post_meta($post_id, '_gyrojob_seo_post_meta_keywords', true);
            $meta_noindex = get_post_meta($post_id, '_gyrojob_seo_post_meta_noindex', true);
            $meta_nofollow = get_post_meta($post_id, '_gyrojob_seo_post_meta_nofollow', true);
            $meta_canonical = get_post_meta($post_id, '_gyrojob_seo_post_meta_canonical', true);


?>    <!-- Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
<?php


            if ($meta_title) {
                echo '<title>' . esc_html($meta_title) . '</title>' . "\n";
            }
            if ($meta_description) {
                echo '<meta name="description" content="' . esc_attr($meta_description) . '">' . "\n";
            }
            if ($meta_keywords) {
                echo '<meta name="keywords" content="' . esc_attr($meta_keywords) . '">' . "\n";
            }
            if ($meta_noindex === '1') {
                echo '<meta name="robots" content="noindex' . ($meta_nofollow === '1' ? ',nofollow' : '') . '">' . "\n";
            } elseif ($meta_nofollow === '1') {
                echo '<meta name="robots" content="nofollow">' . "\n";
            }
            if ($meta_canonical) {
                echo '<link rel="canonical" href="' . esc_url($meta_canonical) . '">' . "\n";
            }
            
?>	<!-- END Gyrojob seo Meta Description - login to - https://plugin.gyrojob.com -->
<?php

        }
    }















/*

    public function add_shop_meta_settings() {
        add_submenu_page(
            'woocommerce',
            'Shop Meta Tags',
            'Shop Meta Tags',
            'manage_options',
            'shop-meta-tags',
            [$this, 'render_shop_meta_settings']
        );
    }

    public function render_shop_meta_settings() {
        wp_nonce_field( 'save_meta_box_data', 'cmt_meta_post_page_nonce' );
        if ($_POST['shop_meta_tags_submit']) {
            update_option('shop_meta_title', sanitize_text_field($_POST['shop_meta_title']));
            update_option('shop_meta_description', sanitize_textarea_field($_POST['shop_meta_description']));
            update_option('shop_meta_keywords', sanitize_text_field($_POST['shop_meta_keywords']));
            update_option('shop_meta_noindex', isset($_POST['shop_meta_noindex']) ? sanitize_text_field($_POST['shop_meta_noindex']) : '');
            update_option('shop_meta_nofollow', isset($_POST['shop_meta_nofollow']) ? sanitize_text_field($_POST['shop_meta_nofollow']) : '');
            update_option('shop_meta_canonical', esc_url_raw($_POST['shop_meta_canonical']));
            echo '<div class="updated"><p>Settings saved.</p></div>';
        }

        $shop_meta_title = get_option('shop_meta_title', '');
        $shop_meta_description = get_option('shop_meta_description', '');
        $shop_meta_keywords = get_option('shop_meta_keywords', '');
        $shop_meta_noindex = get_option('shop_meta_noindex', '');
        $shop_meta_nofollow = get_option('shop_meta_nofollow', '');
        $shop_meta_canonical = get_option('shop_meta_canonical', '');
        ?>
        <div class="wrap">
            <h1>Shop Meta Tags</h1>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="shop_meta_title">Title</label></th>
                        <td><input type="text" name="shop_meta_title" id="shop_meta_title" value="<?php echo esc_attr($shop_meta_title); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="shop_meta_description">Description</label></th>
                        <td><textarea name="shop_meta_description" id="shop_meta_description" class="large-text"><?php echo esc_textarea($shop_meta_description); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="shop_meta_keywords">Keywords</label></th>
                        <td><input type="text" name="shop_meta_keywords" id="shop_meta_keywords" value="<?php echo esc_attr($shop_meta_keywords); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Noindex</th>
                        <td>
                            <label><input type="radio" name="shop_meta_noindex" value="1" <?php checked($shop_meta_noindex, '1'); ?>> Yes</label>
                            <label><input type="radio" name="shop_meta_noindex" value="0" <?php checked($shop_meta_noindex, '0'); ?>> No</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Nofollow</th>
                        <td>
                            <label><input type="radio" name="shop_meta_nofollow" value="1" <?php checked($shop_meta_nofollow, '1'); ?>> Yes</label>
                            <label><input type="radio" name="shop_meta_nofollow" value="0" <?php checked($shop_meta_nofollow, '0'); ?>> No</label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="shop_meta_canonical">Canonical URL</label></th>
                        <td><input type="text" name="shop_meta_canonical" id="shop_meta_canonical" value="<?php echo esc_attr($shop_meta_canonical); ?>" class="regular-text"></td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="shop_meta_tags_submit" id="shop_meta_tags_submit" class="button-primary" value="Save Changes">
                </p>
            </form>
        </div>
        <?php
    }

*/


















}
//new CustomMetaTags();